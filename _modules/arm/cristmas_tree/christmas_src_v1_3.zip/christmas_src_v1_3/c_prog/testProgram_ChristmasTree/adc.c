/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 * Description:
 *    Christmas tree
 *
 *****************************************************************************/

#include "boardVersion.h"

#ifdef BOARD_VERSION_LPC2104
#else

#include "../pre_emptive_os/api/osapi.h"
#include "../pre_emptive_os/api/general.h"
#include <printf_P.h>
#include <lpc2xxx.h>
#include "pins.h"
#include "../startup/config.h"
#include "adc.h"
#include "irq/irqUart.h"

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/
#define CRYSTAL_FREQUENCY FOSC
#define PLL_FACTOR        PLL_MUL
#define VPBDIV_FACTOR     PBSD


/*****************************************************************************
 *
 * Description:
 *    Start a conversion of one selected analogue input and return
 *    10-bit result.
 *
 * Params:
 *    [in] channel - analogue input channel to convert.
 *
 * Return:
 *    10-bit conversion result
 *
 ****************************************************************************/
tU16
getAnalogueInput(tU8 channel)
{
  volatile tU32 cpsrReg;
  tU16 returnResult;

  //disable IRQ
  cpsrReg = disIrq();

	//start conversion now (for selected channel)
	ADCR = (ADCR & 0xFFFFFF00) | (1 << channel) | (1 << 24);
	
	//wait til done
	while((ADDR & 0x80000000) == 0)
	  ;

	//get result and adjust to 10-bit integer
	returnResult = (ADDR>>6) & 0x3FF;

  //enable IRQ
  restoreIrq(cpsrReg);
  
  return returnResult;
}

/*****************************************************************************
 *
 * Description:
 *
 ****************************************************************************/
void
initAdc(void)
{
	volatile tU32 integerResult;

	//
  //Initialize ADC: AIN0 = P0.22, AIN1 = P0.23
  //
  PINSEL1 &= ~0x0000f000;
  PINSEL1 |=  0x0000f000;
  
  //initialize ADC
  ADCR = (1 << 0)                             |  //SEL = 1, dummy channel #1
         ((CRYSTAL_FREQUENCY *
           PLL_FACTOR /
           VPBDIV_FACTOR) / 4500000 - 1) << 8 |  //set clock division factor, so ADC clock is 4.5MHz
         (0 << 16)                            |  //BURST = 0, conversions are SW controlled
         (0 << 17)                            |  //CLKS  = 0, 11 clocks = 10-bit result
         (1 << 21)                            |  //PDN   = 1, ADC is active
         (1 << 24)                            |  //START = 1, start a conversion now
         (0 << 27);							                 //EDGE  = 0, not relevant when start=1

  //short delay and dummy read
  osSleep(1);
  integerResult = ADDR;
}

#endif
