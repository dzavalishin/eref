/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2006 Embedded Artists AB
 *
 *****************************************************************************/

extern tU8  progKeyPressed;
extern tU8  volKeyPressed;
extern tU32 volumeFactor;

void initKeys(void);
void sampleKeys(void);

