/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 * Description:
 *    Christmas tree
 *
 *****************************************************************************/

#include "boardVersion.h"
#include "../pre_emptive_os/api/osapi.h"
#include "../pre_emptive_os/api/general.h"
#include <printf_P.h>
#include <ea_init.h>
#include <lpc2xxx.h>
#include <consol.h>
#include "pins.h"
#include "song.h"

#ifdef BOARD_VERSION_LPC2104
  #include "key.h"
#else
  #include "adc.h"
#endif

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/

static tCntSem songSem;
static tU8 *pPendingSong;


#ifdef BOARD_VERSION_LPC2104
extern tU32 globalGreen;

/*****************************************************************************
 *
 * Description:
 *
 ****************************************************************************/
static void
updateGreenLed(void)
{
  PWM_MR5 = ((PWM_MR0 * globalGreen) / 200);
  PWM_LER  = 0x25;
}
#endif


/*****************************************************************************
 *
 * Description:
 *
 ****************************************************************************/
void
initSong(void)
{
#ifdef BOARD_VERSION_LPC2104
	//Enable PWM2 on P0.7
  PINSEL0 &= 0xffff3fff;
  PINSEL0 |= 0x00008000;
  IODIR   |= 0x00000080;

  //initialize PWM unit and start PWM2
  PWM_PR  = 0x00;    // Prescale Register
  PWM_MCR = 0x02;    // Match Control Register
  PWM_MR0 = 10000;   //
  PWM_MR2 = 10000;
  PWM_LER = 0x05;    // Latch Enable Register
  PWM_PCR = 0x0400;  // Prescale Counter Register PWMENA2
  PWM_TCR = 0x09;    // Counter Enable och PWM Enable
  updateGreenLed();
#else
	//Enable MAT on P0.7
  PINSEL0 &= 0xffff3fff;
  PINSEL0 |= 0x00008000;

  //initialize and start Timer #2
  T2TCR = 0x00000002;                           //disable and reset Timer1
  T2PC  = 0x00000010;                           //prescale clock
  T2MR1 = 1 *                                   //16 ms PWM period time
         ((CRYSTAL_FREQUENCY * PLL_FACTOR) / (1000 * VPBDIV_FACTOR));
  T2MR0 = 0;                                    //Set output to off
  T2IR  = 0x000000ff;                           //reset all flags before enable IRQs
  T2MCR = 0x00000010;                           //reset counter on MR1 match
  PWM2CON = 0x00000001;                         //enable PWM on output 0
  T2TCR = 0x00000001;                           //start Timer2
#endif

  osSemInit(&songSem, 0);
}

/*****************************************************************************
 *
 * Description:
 *    
 *
 ****************************************************************************/
static void
playNote(tU32 value, tU32 time, tU32 gap)
{
#ifdef BOARD_VERSION_LPC2104
  PWM_MR0 = value;

  if (volumeFactor < 512)
    PWM_MR2 = value - (value / volumeFactor);
  else
    PWM_MR2 = value;
//  PWM_LER = 0x05;
  updateGreenLed();

  osSleep(time);
  
  //Pause
  PWM_MR0 = 10000;
  PWM_MR2 = 10000;
//  PWM_LER = 0x05;
  updateGreenLed();

#else
	tU8 volumeFactor;
	
	volumeFactor = (getAnalogueInput(AIN1) >> 3) + 2;
  T2MR1 = value;
  
  if (volumeFactor < 128)
    T2MR0 = value / volumeFactor;
  else
    T2MR0 = 0;
  osSleep(time);
  T2MR0 = 0;
#endif

  osSleep(gap);
}

/*****************************************************************************
 *
 * Description:
 *    
 * Params:
 *    [in] pSongString - 
 *
 ****************************************************************************/
void
playSong(tU8 *pSongString)
{
  tU8 error;
  
	//save command pointer
  pPendingSong = pSongString;

  //signal semaphore
  osSemGive(&songSem, &error);
}


/*****************************************************************************
 *
 * Description:
 *    
 * Params:
 *    [in] pSongString - 
 *
 ****************************************************************************/
void
executeSong(tU8 *pSongString)
{
	tU32 note;
	tU32 length;
	tU32 gap;

	while(*pSongString != 0x00)
	{
		//get note
		switch(*pSongString++)
		{
		  case 'b': note = noteB2; break;
//		  case '': note = noteBb2; break;
		  case 'a': note = noteA2; break;
//		  case '': note = noteAb2; break;
		  case 'g': note = noteG2; break;
//		  case '': note = noteGb2; break;
		  case 'f': note = noteF2; break;
		  case 'e': note = noteE2; break;
//		  case '': note = noteEb2; break;
		  case 'd': note = noteD2; break;
//		  case '': note = noteDb2; break;
		  case 'c': note = noteC2; break;

		  case 'B': note = noteB; break;
//		  case '': note = noteBb; break;
		  case 'A': note = noteA; break;
//		  case '': note = noteAb; break;
		  case 'G': note = noteG; break;
//		  case '': note = noteGb; break;
		  case 'F': note = noteF; break;
		  case 'E': note = noteE; break;
//		  case '': note = noteEb; break;
		  case 'D': note = noteD; break;
//		  case '': note = noteDb; break;
		  case 'C': note = noteC; break;
		  default:  note = noteC; break;
	  }
		
		//get length (units of 25 ms)
		switch(*pSongString++)
		{
		  case '1': length =  25; break;
		  case '2': length =  50; break;
		  case '3': length =  75; break;
		  case '4': length = 100; break;
		  case '5': length = 125; break;
		  case '6': length = 150; break;
		  case '7': length = 175; break;
		  case '8': length = 200; break;
		  case '9': length = 225; break;
		  default:  length =  50; break;
	  }
		
    if (*pSongString != 0x00)
    {
  		//get gap
	  	switch(*pSongString++)
		  {
		    case ',': gap =  5; break;
		    case '.': gap = 10; break;
		    default:  gap =  5; break;
	    }
	  }
	  else gap = 5;

		playNote(note, length, gap);
  }
}

/*****************************************************************************
 *
 * Description:
 *    
 ****************************************************************************/
void
handleSong(void)
{
  tU8 error;

  for(;;)
	{
		//wait for semaphore
    osSemTake(&songSem, 0, &error);

		//execute command string
    executeSong(pPendingSong);
	}
}

