/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2006 Embedded Artists AB
 *
 *****************************************************************************/

#include "boardVersion.h"

#ifdef BOARD_VERSION_LPC2104

#include "../pre_emptive_os/api/osapi.h"
#include "../pre_emptive_os/api/general.h"
#include <printf_P.h>
#include <lpc2xxx.h>
#include <consol.h>
#include "pins.h"

tU8  progKeyPressed;
tU8  volKeyPressed;
tU32 volumeFactor;

static tU32 key1cnt;
static tU32 key2cnt;


/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
void
initKeys(void)
{
  IODIR &= ~(KEY1 | KEY2);  //key signals are inputs
  progKeyPressed = FALSE;
  volKeyPressed = FALSE;
  key1cnt = 0;
  key2cnt = 0;
  
  volumeFactor = 16;
}

/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
void
sampleKeys(void)
{
  //check if key #1 pressed
  if ((IOPIN & KEY1) == 0)
  {
    key1cnt++;
    if (key1cnt == 2)
    {
      volKeyPressed = TRUE;
      if (volumeFactor < 512)
        volumeFactor <<= 1;
      else
        volumeFactor = 4;

//printf("\nvol = %x\n", volumeFactor);
    }
  }
  else
  {
    key1cnt = 0;
  }

  //check if key #2 pressed
  if ((IOPIN & KEY2) == 0)
  {
    key2cnt++;
    if (key2cnt == 2)
    {
      progKeyPressed = TRUE;
    }
  }
  else
  {
    key2cnt = 0;
  }
}

#else
//LPC2103 version does not use keys at all...
#endif


