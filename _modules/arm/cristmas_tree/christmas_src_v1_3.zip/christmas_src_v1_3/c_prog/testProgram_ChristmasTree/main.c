/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 * Description:
 *    Christmas tree
 *
 *****************************************************************************/

#include "boardVersion.h"
#include "../pre_emptive_os/api/osapi.h"
#include "../pre_emptive_os/api/general.h"
#include <printf_P.h>
#include <ea_init.h>
#include <lpc2xxx.h>
#include <consol.h>
#include <string.h>
#include "pins.h"
#include "lcd.h"
#include "rgb.h"
#include "song.h"
#include "uart.h"
#include "../startup/config.h"

#ifdef BOARD_VERSION_LPC2104
  #include "key.h"
#else
  #include "adc.h"
#endif

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/
#define CRYSTAL_FREQUENCY FOSC
#define PLL_FACTOR        PLL_MUL
#define VPBDIV_FACTOR     PBSD

#define PROC1_STACK_SIZE 500
#define PROC2_STACK_SIZE 500
#define PROC3_STACK_SIZE 500
#define PROC4_STACK_SIZE 500
#define PROC5_STACK_SIZE 500
#define INIT_STACK_SIZE  500

static tU8 proc1Stack[PROC1_STACK_SIZE];
static tU8 proc2Stack[PROC2_STACK_SIZE];
static tU8 proc3Stack[PROC3_STACK_SIZE];
static tU8 proc4Stack[PROC4_STACK_SIZE];
static tU8 proc5Stack[PROC5_STACK_SIZE];
static tU8 initStack[INIT_STACK_SIZE];
tU8 pid1;
tU8 pid2;
tU8 pid3;
tU8 pid4;
tU8 pid5;

tU32 users = 0;

volatile tU32 currentTime = 0;

static void proc1(void* arg);
static void proc2(void* arg);
static void proc3(void* arg);
static void proc4(void* arg);
static void proc5(void* arg);
static void initProc(void* arg);

void matrixControl(void);
void testI2C(void);

struct
{
	tU8  preBuffer[16];
	tU8  buffer[256];
	tU8  character;
	tU16 bufferIndex;
	tU8  newMessageFlag;
} rx;

tU32 usersTimeout = 0;
#define USERS_TIMEOUT 200  //10 seconds


/*****************************************************************************
 *
 * Description:
 *    The first function to execute 
 *
 ****************************************************************************/
int
main(void)
{
  tU8 error;
  tU8 pid;

  //immediately turn off buzzer (if connected)
  IODIR0 |= BUZZER;
  IOSET0  = BUZZER;
  
  //immediatley turn off all LEDs
  IOCLR = (LEDMATRIX_COL1 | LEDMATRIX_COL2 | LEDMATRIX_COL3 | LEDMATRIX_COL4 | LEDMATRIX_COL5 | LEDMATRIX_COL6) |
          (LEDMATRIX_ROW1 | LEDMATRIX_ROW2 | LEDMATRIX_ROW3 | LEDMATRIX_ROW4 | LEDMATRIX_ROW5 | LEDMATRIX_ROW6 | LEDMATRIX_ROW7 | LEDMATRIX_ROW8);
  IODIR |=(LEDMATRIX_COL1 | LEDMATRIX_COL2 | LEDMATRIX_COL3 | LEDMATRIX_COL4 | LEDMATRIX_COL5 | LEDMATRIX_COL6) |
          (LEDMATRIX_ROW1 | LEDMATRIX_ROW2 | LEDMATRIX_ROW3 | LEDMATRIX_ROW4 | LEDMATRIX_ROW5 | LEDMATRIX_ROW6 | LEDMATRIX_ROW7 | LEDMATRIX_ROW8);
  IOCLR = (LEDMATRIX_COL1 | LEDMATRIX_COL2 | LEDMATRIX_COL3 | LEDMATRIX_COL4 | LEDMATRIX_COL5 | LEDMATRIX_COL6) |
          (LEDMATRIX_ROW1 | LEDMATRIX_ROW2 | LEDMATRIX_ROW3 | LEDMATRIX_ROW4 | LEDMATRIX_ROW5 | LEDMATRIX_ROW6 | LEDMATRIX_ROW7 | LEDMATRIX_ROW8);

  //immediatley turn off RGB-LED
  IODIR0 |= (RGBLED_R | RGBLED_G | RGBLED_B);
  IOCLR0  = (RGBLED_R | RGBLED_G | RGBLED_B);
  
  //initialize uart #0: 57.6 kbps, 8N1, no FIFO
  initUart0(B57600((CRYSTAL_FREQUENCY * PLL_FACTOR) / VPBDIV_FACTOR), UART_8N1, UART_FIFO_OFF);

  osInit();
  osCreateProcess(initProc, initStack, INIT_STACK_SIZE, &pid, 1, NULL, &error);
  osStartProcess(pid, &error);
  
  osStart();
  return 0;
}

/*****************************************************************************
 *
 * Description:
 *    A process entry function 
 *
 * Params:
 *    [in] arg - This parameter is not used in this application. 
 *
 ****************************************************************************/
static void
proc1(void* arg)
{
	tU32 previousEventTime;
	tU32 nextEventMs;
  tU8  error;
  
  rx.newMessageFlag = FALSE;

  osCreateProcess(proc5, proc5Stack, PROC5_STACK_SIZE, &pid5, 3, NULL, &error);
  osStartProcess(pid5, &error);

  //print welcome message and play song
  osSleep(300);
  outputToLcd("RCb'0'Embedded Artists'h'0'Christmas Tree'd1,0,4 D1,32,4 d1,0,4 D1,32,4 d1,0,4 D1,32,4 d1,0,4 D1,32,4" \
              "h\"Christmas Tree - controlled by LPC2104, the amazing ARM7 MCU from NXP - Enjoy!\"300 d1,0,4");
  playSong("E2,E2,E4,E2,E2,E4,E2,G2,C2,D2,E8,F2,F2,F2,F2,F2,E2,E2,E2,E2,D2,D2,E2,D4,G4," \
           "E2,E2,E4,E2,E2,E4,E2,G2,C2,D2,E8,F2,F2,F2,F2,F2,E2,E2,E2,G2,G2,F2,D2,C8");
  osSleep(4800);  //wait 48 seconds for first message and song

	previousEventTime = 0;
  nextEventMs = 60000;
	for(;;)
	{
		osSleep(100);

    //check if time to print Merry Christmas message
		if ((currentTime - previousEventTime) > nextEventMs)
		{
      static tU8 message[50];

      nextEventMs = 120000;
			previousEventTime = currentTime;
			
			//only print message about 'no of users' if connected
			if (usersTimeout > 0)
			{
  			//create message for number of users
  			strcpy(message, "RCBH'0'No of users:    '500d1,0,4 200 ");

        //copy 'no of users'
        if (users/100 > 0)
          message[20] = users/100 + '0';
        if ((users/100 > 0) || (((users / 10) % 10) > 0))
          message[21] = (users / 10) % 10 + '0';
        message[22] = users % 10 + '0';
        
        while(outputToLcd(message) == FALSE)
          osSleep(100);
      }

			while(outputToLcd("RCBH'20'Merry Christmas'h'20'& Happy New Year'800 d1,0,10 D1,32,10 d1,0,10 D1,32,10 d1,0,10 D1,32,10 d1,0,10 D1,32,10 d1,0,10") == FALSE)
			  osSleep(100);

			if (usersTimeout > 0)
			{
        while(outputToLcd(message) == FALSE)
          osSleep(100);
      }
		}
    
    if(rx.newMessageFlag == TRUE)
    {
    	static tU8 alternateSong = 0;

      while(outputToLcd("RCBH'20'New message...'d1,0,4 D1,32,4 d1,0,4 D1,32,4 d1,0,4 D1,32,4") == FALSE)
        osSleep(100);

      //decide which song to play
      if (alternateSong == 0)
      {
      	playSong("G2,A2,G2,E8.G2,A2,G2,E8.d4.d2,B8,c4,c2,G8,A4,A2,c2,B2,A2,G2,A2,G2,E8");
      	alternateSong = 1;
      }
      else
      {
        playSong("E2,E2,E4,E2,E2,E4,E2,G2,C2,D2,E8,F2,F2,F2,F2,F2,E2,E2,E2,E2,D2,D2,E2,D4,G4,E2,E2,E4,E2,E2,E4,E2,G2,C2,D2,E8,F2,F2,F2,F2,F2,E2,E2,E2,G2,G2,F2,D2,C8");
        alternateSong = 0;
      }
      
      rx.preBuffer[0] = 'h';
      rx.preBuffer[1] = '"';
      rx.preBuffer[2] = ' ';
      rx.preBuffer[3] = ' ';
      rx.preBuffer[4] = ' ';
      rx.preBuffer[5] = ' ';
      rx.preBuffer[6] = ' ';
      rx.preBuffer[7] = ' ';
      rx.preBuffer[8] = ' ';
      rx.preBuffer[9] = ' ';
      rx.preBuffer[10] = ' ';
      rx.preBuffer[11] = ' ';
      rx.preBuffer[12] = ' ';
      rx.preBuffer[13] = ' ';
      rx.preBuffer[14] = ' ';
      rx.preBuffer[15] = ' ';
      rx.buffer[2 + rx.buffer[1]] = '"';
      rx.buffer[0] = ' ';
      rx.buffer[1] = ' ';
      while(outputToLcd(&rx.preBuffer[0]) == FALSE)
        osSleep(100);

      while(outputToLcd(" B200d1,0,10 ") == FALSE)
        osSleep(100);

      while(outputToLcd("RCBH'20'New message...'d1,0,4 D1,32,4 d1,0,4 D1,32,4") == FALSE)
        osSleep(100);

      while(outputToLcd(&rx.preBuffer[0]) == FALSE)
        osSleep(100);

      while(outputToLcd(" B200d1,0,10C  ") == FALSE)
        osSleep(100);

      rx.newMessageFlag = FALSE;
    }
  }
}

/*****************************************************************************
 *
 * Description:
 *    A process entry function 
 *
 * Params:
 *    [in] arg - This parameter is not used in this application. 
 *
 ****************************************************************************/
static void
proc2(void* arg)
{
	matrixControl();
}

/*****************************************************************************
 *
 * Description:
 *    A process entry function 
 *
 * Params:
 *    [in] arg - This parameter is not used in this application. 
 *
 ****************************************************************************/
static void
proc3(void* arg)
{
  handleLcd();
}

/*****************************************************************************
 *
 * Description:
 *    A process entry function 
 *
 * Params:
 *    [in] arg - This parameter is not used in this application. 
 *
 ****************************************************************************/
static void
proc4(void* arg)
{
  handleSong();
}

/*****************************************************************************
 *
 * Description:
 *    A process entry function 
 *
 * Params:
 *    [in] arg - This parameter is not used in this application. 
 *
 ****************************************************************************/
static void
proc5(void* arg)
{
	tU8 i;

	rx.bufferIndex = 0;
	for(;;)
	{
#ifdef BOARD_VERSION_LPC2104
	  sampleKeys();
#endif

		osSleep(5);
		if (usersTimeout > 0)
		  usersTimeout--;

    //check if any charcters received
    while (uart0GetChar(&rx.character))
    {
    	//check if ping request
    	if (rx.character == 0xf4)
    	{
	      uart0SendChar(0xf4);
        usersTimeout = USERS_TIMEOUT;
      }

    	//check if ping request
    	else if (rx.character == 0xf3)
    	{
    		if (rx.newMessageFlag == FALSE)
	        uart0SendChar(0xf3);  //ACK = OK
	      else
	        uart0SendChar(0xf4);  //NACK
    	}

    	else
    	{
    		//only receive if last message has been processed
    		if (rx.newMessageFlag == FALSE)
    		{
      	  //check if start of message
      	  if ((rx.character == 0xf0) || (rx.character == 0xf1) || (rx.character == 0xf2))
      	  {
      		  rx.bufferIndex = 1;
    	  	  rx.buffer[0] = rx.character;
    	    }
    	    //fill received characters in buffer
    	    else
    	    {
    	  	  if (rx.bufferIndex < sizeof(rx.buffer))
    	  	    rx.buffer[rx.bufferIndex++] = rx.character;
    		
    	      //check if buffer complete
    	      if ((rx.bufferIndex > 1) && (rx.bufferIndex == (rx.buffer[1] + 2)))
    	      {
	            //signal that command has been accepted
	            uart0SendChar(rx.buffer[0]);
	          
  	          //handle received command
	            switch(rx.buffer[0])
	            {
        	      //0xf0 = number of users
	            	case 0xf0:
	            	users = 0;
	            	for(i=0; i<rx.buffer[1]; i++)
	          	  {
	          		  users *= 10;
  	          		users += rx.buffer[2+i] - '0';
	            	}
	            	break;

      	        //0xf1 = message
	            	case 0xf1:
                rx.newMessageFlag = TRUE;
	          	  break;

        	      //0xf2 = prio-message
	            	case 0xf2:
                rx.newMessageFlag = TRUE;
	            	break;

	            	default:
	            	break;
	            }
	          }
	        }
      	}
      }
    }
  }
}

/*****************************************************************************
 *
 * Description:
 *    The entry function for the initialization process. 
 *
 * Params:
 *    [in] arg - This parameter is not used in this application. 
 *
 ****************************************************************************/
static void
initProc(void* arg)
{
  tU8 error;

  printf("\n\n\n\n\n*******************************************************\n");
  printf("*                                                     *\n");
  printf("* Welcome to Embedded Artists' Christmas Tree...      *\n");
  printf("* ...based on NXP's amazing LPC2104 ARM7TDMI-S        *\n");
  printf("* processor with 128kB FLASH and 16kB SRAM            *\n");
  printf("*                                                     *\n");
  printf("* Program version: 1.2a                               *\n");
  printf("* Date: 20 November 2006                              *\n");
  printf("* (C) Embedded Artists 2005-2006                      *\n");
  printf("*                                                     *\n");
  printf("*******************************************************\n");

	//init buzzer
	initSong();

  //init RGB-LED
  initRGB();

#ifdef BOARD_VERSION_LPC2104
  //Initialize keys
  initKeys();
#else
  //Initialize ADC
  initAdc();
#endif

  //Initialize LCD
  initLcd();

  //Test EEPROM via I2C
  testI2C();
  
  osCreateProcess(proc1, proc1Stack, PROC1_STACK_SIZE, &pid1, 3, NULL, &error);
  osStartProcess(pid1, &error);
  osCreateProcess(proc2, proc2Stack, PROC2_STACK_SIZE, &pid2, 3, NULL, &error);
  osStartProcess(pid2, &error);
  osCreateProcess(proc3, proc3Stack, PROC3_STACK_SIZE, &pid3, 3, NULL, &error);
  osStartProcess(pid3, &error);
  osCreateProcess(proc4, proc4Stack, PROC4_STACK_SIZE, &pid4, 3, NULL, &error);
  osStartProcess(pid4, &error);

  osDeleteProcess();
}

/*****************************************************************************
 *
 * Description:
 *    The timer tick entry function that is called once every timer tick
 *    interrupt in the RTOS. Observe that any processing in this
 *    function must be kept as short as possible since this function
 *    execute in interrupt context.
 *
 * Params:
 *    [in] elapsedTime - The number of elapsed milliseconds since last call.
 *
 ****************************************************************************/
void
appTick(tU32 elapsedTime)
{
	currentTime += elapsedTime;
}
