/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 *****************************************************************************/

#include "../boardVersion.h"
#include "../../pre_emptive_os/api/general.h"
#include <lpc2xxx.h>
#include "../pins.h"

extern tU8 pattern[6];
static tU32 columnCounter = 0;


void isrLedMatrix(void)
{
	tU32 i;
	
#ifdef BOARD_VERSION_LPC2104
	while(T1IR)
	{
   	if (T1IR & 0x04)
 	  {
      IOSET0 = RGBLED_R;
      T1IR = 0x04;
 	  }

   	if (T1IR & 0x08)
 	  {
      IOSET0 = RGBLED_B;
      T1IR = 0x08;
  	}

	  if (T1IR & 0x01)
	  {
  	  //Clear previous output
      IOCLR = (LEDMATRIX_COL1 | LEDMATRIX_COL2 | LEDMATRIX_COL3 | LEDMATRIX_COL4 | LEDMATRIX_COL5 | LEDMATRIX_COL6) |
              (LEDMATRIX_ROW1 | LEDMATRIX_ROW2 | LEDMATRIX_ROW3 | LEDMATRIX_ROW4 | LEDMATRIX_ROW5 | LEDMATRIX_ROW6 | LEDMATRIX_ROW7 | LEDMATRIX_ROW8);

      for(i=0; i<50; i++)
        asm volatile (" nop ");

      switch(columnCounter)
 	    {
 		    case 0:
 		      //output next column
   		    IOSET = LEDMATRIX_COL1 | ((pattern[0]) << 8);
 	  	    break;
   		  case 1:
 	  	    //output next column
   	  	  IOSET = LEDMATRIX_COL2 | ((pattern[1]) << 8);
 	  	    break;
   		  case 2:
 	  	    //output next column
   	  	  IOSET = LEDMATRIX_COL3 | ((pattern[2]) << 8);
 	  	    break;
   		  case 3:
 	  	    //output next column
   	  	  IOSET = LEDMATRIX_COL4 | ((pattern[3]) << 8);
 	  	    break;
   		  case 4:
 	  	    //output next column
   	  	  IOSET = LEDMATRIX_COL5 | ((pattern[4]) << 8);
 	  	    break;
   		  case 5:
 	  	    //output next column
   	  	  IOSET = LEDMATRIX_COL6 | ((pattern[5]) << 8);
 	  	    break;
     		default:
 	    	  columnCounter = 0;
 		      break;
     	}
 	    columnCounter++;
     	if (columnCounter > 5)
 	      columnCounter = 0;

      IOCLR0 = (RGBLED_R | RGBLED_B);
      T1IR = 0x01;
 	  }
  }
#else
	//Clear previous output
  IOCLR = (LEDMATRIX_COL1 | LEDMATRIX_COL2 | LEDMATRIX_COL3 | LEDMATRIX_COL4 | LEDMATRIX_COL5 | LEDMATRIX_COL6) |
          (LEDMATRIX_ROW1 | LEDMATRIX_ROW2 | LEDMATRIX_ROW3 | LEDMATRIX_ROW4 | LEDMATRIX_ROW5 | LEDMATRIX_ROW6 | LEDMATRIX_ROW7 | LEDMATRIX_ROW8);

  for(i=0; i<75; i++)
    asm volatile (" nop ");


  switch(columnCounter)
 	{
 		case 0:
 		  //output next column
 		  IOSET = LEDMATRIX_COL1 | ((pattern[0]) << 8);
 		  break;
 		case 1:
 		  //output next column
 		  IOSET = LEDMATRIX_COL2 | ((pattern[1]) << 8);
 		  break;
 		case 2:
 		  //output next column
 		  IOSET = LEDMATRIX_COL3 | ((pattern[2]) << 8);
 		  break;
 		case 3:
 		  //output next column
 		  IOSET = LEDMATRIX_COL4 | ((pattern[3]) << 8);
 		  break;
 		case 4:
 		  //output next column
 		  IOSET = LEDMATRIX_COL5 | ((pattern[4]) << 8);
 		  break;
 		case 5:
 		  //output next column
 		  IOSET = LEDMATRIX_COL6 | ((pattern[5]) << 8);
 		  break;
 		default:
 		  columnCounter = 0;
 		  break;
 	}
 	columnCounter++;
 	if (columnCounter > 5)
 	  columnCounter = 0;
#endif

  T1IR        = 0xff;        //reset all IRQ flags
  VICVectAddr = 0x00;        //dummy write to VIC to signal end of interrupt
}

