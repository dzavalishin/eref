/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 *****************************************************************************/

#ifndef _IRQ_TIMER_H_
#define _IRQ_TIMER_H_

void isrLedMatrix(void);

#endif
