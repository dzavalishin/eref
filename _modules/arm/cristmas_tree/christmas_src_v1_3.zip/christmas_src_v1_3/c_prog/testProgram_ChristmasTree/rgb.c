/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 * Description:
 *
 *****************************************************************************/

#include "boardVersion.h"
#include "../pre_emptive_os/api/osapi.h"
#include "../pre_emptive_os/api/general.h"
#include <printf_P.h>
#include <lpc2xxx.h>
#include "pins.h"
#include "rgb.h"
#include "irq/irqTimer.h"
#include "../startup/config.h"

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/
#define CRYSTAL_FREQUENCY FOSC
#define PLL_FACTOR        PLL_MUL
#define VPBDIV_FACTOR     PBSD

#ifdef BOARD_VERSION_LPC2104
tU32 globalGreen;
#endif

/*****************************************************************************
 *
 * Description:
 *
 ****************************************************************************/
void
initRGB(void)
{
  tU8 i;

#ifdef BOARD_VERSION_LPC2104
  PINSEL1 &= 0xfffff3ff;
  PINSEL1 |= 0x00000400;
#else
	//Enable MAT1.2 on P0.19, MAT1.3 on P0.20, and PWM5 on P0.21
  PINSEL1 &= 0xfffff03f;
  PINSEL1 |= 0x00000a80;
#endif

  //initialize and start Timer #1
  T1TCR = 0x00000002;                           //disable and reset Timer1
  T1PC  = 0x0000000a;                           //prescale clock
  T1MR0 = 1 *                                   //10 ms PWM period time
         ((CRYSTAL_FREQUENCY * PLL_FACTOR) / (1000 * VPBDIV_FACTOR));
  T1MR2 = T1MR0;                                //Set output to off
  T1MR3 = T1MR0;                                //Set output to off
  T1IR  = 0x000000ff;                           //reset all flags before enable IRQs
#ifdef BOARD_VERSION_LPC2104
  T1MCR = 0x00000243;                           //reset counter on MR0 match and generate interrupt
                                                //interrupt on MR2 and MR3
  T1TCR = 0x00000001;                           //start Timer1
#else
  T1MCR = 0x00000003;                           //reset counter on MR0 match and generate interrupt
  PWM1CON = 0x0000000c;                         //enable PWM on output 2 & 3
  T1TCR = 0x00000001;                           //start Timer1
#endif


  //initialize VIC for Timer1 interrupts
  VICIntSelect &= ~0x00000020;                //Timer1 interrupt is assigned to IRQ (not FIQ)
  VICVectAddr5  = (tU32)isrLedMatrix;       //register ISR address
  VICVectCntl5  =  0x00000020 | 5;       //enable vector interrupt for timer1 (irq #5)
  VICIntEnable  =  0x00000020;       //enable timer1 interrupt
  

#ifdef BOARD_VERSION_LPC2104
  //initialize and start PWM5
  PWM_MR0  = 10000;
  PWM_MR5  = 0;
  PWM_LER  = 0x20;    // Latch Enable Register
  PWM_PCR |= 0x2000;  // Prescale Counter Register PWMENA5
  globalGreen = 0;
#else
  //initialize and start Timer #3
  T3TCR = 0x00000002;                           //disable and reset Timer1
  T3PC  = 0x0000000a;                           //prescale clock
  T3MR1 = 1 *                                   //10 ms PWM period time
         ((CRYSTAL_FREQUENCY * PLL_FACTOR) / (1000 * VPBDIV_FACTOR));
  T3MR0 = T3MR1;                                //Set output to off
  T3IR  = 0x000000ff;                           //reset all flags before enable IRQs
  T3MCR = 0x00000010;                           //reset counter on MR1 match
  PWM3CON = 0x00000001;  //enable PWM on output 0
  T3TCR = 0x00000001;                           //start Timer1
#endif

  setRGB('R', 0);
  setRGB('G', 0);
  setRGB('B', 0);
  for(i=0; i<3; i++)
  {
    setRGB('R', 100);
    osSleep(30);
    setRGB('R', 0);
    setRGB('G', 100);
    osSleep(30);
    setRGB('G', 0);
    setRGB('B', 100);
    osSleep(30);
    setRGB('B', 0);
  }
  setRGB('B', 80);
  osSleep(5);
  setRGB('B', 60);
  osSleep(5);
  setRGB('B', 40);
  osSleep(5);
  setRGB('B', 30);
  osSleep(5);
  setRGB('B', 25);
  osSleep(5);
  setRGB('B', 20);
  osSleep(5);
  setRGB('B', 15);
  osSleep(5);
  setRGB('B', 10);
  osSleep(5);
  setRGB('B', 5);
  osSleep(5);
  setRGB('B', 0);
}

/*****************************************************************************
 *
 * Description:
 *
 ****************************************************************************/
void
setRGB(tU8 color, tU32 value)
{
#ifdef BOARD_VERSION_LPC2104
	tU32 registerValue = T1MR0 - ((value * T1MR0) / 200);

  switch(color)
  {
  	case 'R':
    T1MR2 = registerValue + 10;
  	break;
  	case 'G':  //Update PWM5
  	globalGreen = value;
  	PWM_MR5 = ((PWM_MR0 * value) / 200);
    PWM_LER  = 0x20;
  	break;
  	case 'B':
    T1MR3 = registerValue + 10;
  	break;
  	default:
  	break;
  }
#else
	tU32 registerValue = 60000 - ((value * 60000) / 100);

  switch(color)
  {
  	case 'R':
    T1MR2 = registerValue;
  	break;
  	case 'G':
  	T3MR0 = registerValue;
  	break;
  	case 'B':
    T1MR3 = registerValue;
  	break;
  	default:
  	break;
  }
#endif
}

