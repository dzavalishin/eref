/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 * Description:
 *    Christmas tree
 *
 *****************************************************************************/

#ifndef _SONG_H_
#define _SONG_H_

#include "boardVersion.h"
#include "../pre_emptive_os/api/general.h"
#include "../startup/config.h"

/******************************************************************************
 * Defines and typedefs
 *****************************************************************************/
#define CRYSTAL_FREQUENCY FOSC
#define PLL_FACTOR        PLL_MUL
#define VPBDIV_FACTOR     PBSD

#ifdef BOARD_VERSION_LPC2104
  #define ADJ_FACTOR / 10
#else
  #define ADJ_FACTOR / 16
#endif

#define noteB2  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 988 ADJ_FACTOR)
#define noteBb2 (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 932 ADJ_FACTOR)
#define noteA2  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 880 ADJ_FACTOR)
#define noteAb2 (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 831 ADJ_FACTOR)
#define noteG2  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 784 ADJ_FACTOR)
#define noteGb2 (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 740 ADJ_FACTOR)
#define noteF2  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 698 ADJ_FACTOR)
#define noteE2  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 659 ADJ_FACTOR)
#define noteEb2 (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 622 ADJ_FACTOR)
#define noteD2  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 587 ADJ_FACTOR)
#define noteDb2 (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 554 ADJ_FACTOR)
#define noteC2  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 523 ADJ_FACTOR)

#define noteB  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 494 ADJ_FACTOR)
#define noteBb (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 466 ADJ_FACTOR)
#define noteA  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 440 ADJ_FACTOR)
#define noteAb (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 415 ADJ_FACTOR)
#define noteG  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 392 ADJ_FACTOR)
#define noteGb (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 370 ADJ_FACTOR)
#define noteF  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 349 ADJ_FACTOR)
#define noteE  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 330 ADJ_FACTOR)
#define noteEb (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 311 ADJ_FACTOR)
#define noteD  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 294 ADJ_FACTOR)
#define noteDb (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 277 ADJ_FACTOR)
#define noteC  (tU32)((CRYSTAL_FREQUENCY * PLL_FACTOR / VPBDIV_FACTOR) / 262 ADJ_FACTOR)

void initSong(void);
void playSong(tU8 *pSongString);
void handleSong(void);

#endif
