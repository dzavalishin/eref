/******************************************************************************
 *
 * Copyright:
 *    (C) 2000 - 2005 Embedded Artists AB
 *
 *****************************************************************************/
#include "../pre_emptive_os/api/osapi.h"
#include "../pre_emptive_os/api/general.h"
#include <printf_P.h>
#include <lpc2xxx.h>
#include <consol.h>
#include "pins.h"
#include "lcd.h"

static tCntSem lcdSem;
static volatile tU8 *pPendingCommandString;
static volatile tU8 executeLcdReady;

static void initLcdLowlevel(void);


/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
static void
delay37us(void)
{
	volatile tU32 i;

	for(i=0; i<2500; i++)
    asm volatile (" nop"); //delay 15 ns x 2500 = about 37 us delay
}

/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
static void
writeLCD(tU8 reg, tU8 data)
{
	volatile tU8 i;

	if (reg == 0)
	  IOCLR = LCD_RS;
	else
	  IOSET = LCD_RS;
	  
	IOSET = LCD_E;

	IOCLR = (LCD_D4 | LCD_D5 | LCD_D6 | LCD_D7);
	IOSET = ((((tU32)data >> 4) & 0x0f) << 24) & (LCD_D4 | LCD_D5 | LCD_D6 | LCD_D7);
	
	for(i=0; i<64; i++)
    asm volatile (" nop"); //delay 15 ns x 64 = about 1 us delay

	IOCLR = LCD_E;
	for(i=0; i<64; i++)
    asm volatile (" nop"); //delay 15 ns x 64 = about 1 us delay

	IOSET = LCD_E;

	IOCLR = (LCD_D4 | LCD_D5 | LCD_D6 | LCD_D7);
	IOSET = (((tU32)data & 0x0f) << 24) & (LCD_D4 | LCD_D5 | LCD_D6 | LCD_D7);
	
	for(i=0; i<64; i++)
    asm volatile (" nop"); //delay 15 ns x 64 = about 1 us delay

	IOCLR = LCD_E;

	for(i=0; i<64; i++)
    asm volatile (" nop"); //delay 15 ns x 64 = about 1 us delay
}

/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
static void
writeNibbleLCD(tU8 data)
{
	volatile tU8 i;

  IOCLR = LCD_RS;
	  
	IOSET = LCD_E;

	IOCLR = (LCD_D4 | LCD_D5 | LCD_D6 | LCD_D7);
	IOSET = ((((tU32)data >> 4) & 0x0f) << 24) & (LCD_D4 | LCD_D5 | LCD_D6 | LCD_D7);
	
	for(i=0; i<64; i++)
    asm volatile (" nop"); //delay 15 ns x 64 = about 1 us delay

	IOCLR = LCD_E;
	for(i=0; i<64; i++)
    asm volatile (" nop"); //delay 15 ns x 64 = about 1 us delay

}

/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
static void
lcdBacklight(tU8 onOff)
{
	if (onOff == TRUE)
	  IOSET = LCD_PWM;
	else
	  IOCLR = LCD_PWM;
}

/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
static void
lcdBacklightDim(tS32 step, tU8 toValue, tU8 timeStep)
{
	tU32 loops;
	tU32 innerLoop;
	tU8  dimValue;
	tU32 i,j;
	tU8  failsafe = 0;

  //set start value
  if (toValue == 0)
    dimValue = 32;
  else
    dimValue = 0;

  while((dimValue != toValue) && (failsafe < 33))
  {
  	failsafe++;
  	loops = (tU32)timeStep * (tU32)16;
  	for(j=0; j<loops; j++)
  	{
      IOSET = LCD_PWM;
      
      //delay(dimValue)
      innerLoop = (tU32)100*(tU32)dimValue;
      for(i=0; i<innerLoop; i++)
        asm volatile (" nop");

      IOCLR = LCD_PWM;

      //delay(32-dimValue)
      innerLoop = (tU32)100*((tU32)32-(tU32)dimValue);
      for(i=0; i<innerLoop; i++)
        asm volatile (" nop");
  	}
  	
  	dimValue += step;
  }
  
  //set final state
  if (toValue == 0)
    IOCLR = LCD_PWM;
  else
    IOSET = LCD_PWM;
}

/*****************************************************************************
 *
 * Description:
 *    
 ****************************************************************************/
static tU8
getNumber(tU8 **ppCommand, tS32 *pNumber)
{
	tU8 *pDigits = *ppCommand;
	
	while((*pDigits != 0x00) && !((*pDigits >= '0') && (*pDigits <= '9')) && (((tU32)pDigits - (tU32)*ppCommand) < 5))
	  pDigits++;

	*pNumber = 0;
	while((*pDigits != 0x00) && (*pDigits >= '0') && (*pDigits <= '9') && (((tU32)pDigits - (tU32)*ppCommand) < 8))
	{
		*pNumber *= 10;
		*pNumber += *pDigits - '0';
		
		pDigits++;
	}
	
	*ppCommand = pDigits;
	return TRUE;
}

/*****************************************************************************
 *
 * Description:
 *    
 *
 ****************************************************************************/
tU8
outputToLcd(tU8 *pCommandString)
{
  tU8 error;
  
  if (executeLcdReady == TRUE)
  {
  	executeLcdReady = FALSE;

  	//save command pointer
	  pPendingCommandString = pCommandString;

	  //signal semaphore
    osSemGive(&lcdSem, &error);
    
    return TRUE;
  }
  osSleep(5);
  return FALSE;
}

/*****************************************************************************
 *
 * Description:
 *    
 *
 ****************************************************************************/
static void
executeCommandString(tU8 *pCommandString)
{
	tU8 *pCommand;
	tS32 number, number2, number3;

  pCommand = pCommandString;

	//execute command string
	while((*pCommand != 0x00) && (((tU32)pCommand - (tU32)pCommandString) < 270))
	{
		switch(*pCommand)
		{
			case 'R':
			//power off and initialize LCD just to be safe
      initLcd();
      pCommand++;
      break;

			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
      if (getNumber(&pCommand, &number))
        osSleep(number);
      break;

			case 'B':
      lcdBacklight(TRUE);
      pCommand++;
			break;
			
			case 'b':
      lcdBacklight(FALSE);
      pCommand++;
			break;
			
			case 'C':
      //display clear
      writeLCD(0, 0x01);
      osSleep(1); //actually only 1.52 mS needed
      pCommand++;
			break;

			case 'D':
      pCommand++;
      if (getNumber(&pCommand, &number))
        if (getNumber(&pCommand, &number2))
          if (getNumber(&pCommand, &number3))
          {
            lcdBacklightDim(number, number2, number3);
          }
			break;

			case 'd':
      pCommand++;
      if (getNumber(&pCommand, &number))
        if (getNumber(&pCommand, &number2))
          if (getNumber(&pCommand, &number3))
          {
            lcdBacklightDim( (tS32)0 - number, number2, number3);
          }
			break;

			case 'H':
      //cursor home
      writeLCD(0, 0x02);
      osSleep(1);
      pCommand++;
			break;

			case 'h':
      //cursor home
      writeLCD(0, 0x02);
      osSleep(1);

      //move curstor to second row
      writeLCD(0, 0x80 | 0x40);
      delay37us();
      pCommand++;
			break;

			case '\'':
      pCommand++;
      if (getNumber(&pCommand, &number))
      {
        pCommand++;
        while((*pCommand != 0x00) && (*pCommand != '\''))
        {
          writeLCD(1, *pCommand++);
          delay37us();
          if(number > 0)
            osSleep(number);
        }
        pCommand++;
      }
      break;

			case '\"':
			{
				tS32 stringLength = 0;
				tU8 *pStringStart;
				tS32 i;
				tS32 subStringIndex = 0;

        pCommand++;
      
        //get length
        while((pCommand[stringLength] != 0x00) && (pCommand[stringLength] != '\"') && (stringLength < 256))
          stringLength++;
        pStringStart = pCommand;

        //cursor home
        writeLCD(0, 0x02);
        osSleep(1);

        subStringIndex = 0;

        while(subStringIndex <= stringLength)
        {
          //move curstor to second row
          writeLCD(0, 0x80 | 0x40);
          delay37us();

          for(i=0; i<16; i++)
          {
          	if (subStringIndex + i >= stringLength)
              writeLCD(1, ' ');
            else
              writeLCD(1, pStringStart[subStringIndex + i]);
            delay37us();
          }

        	osSleep(40);
      	  subStringIndex++;
        }
        pCommand += stringLength + 1;
      }
      break;

			default:
      pCommand++;
			break;
		}
	}
}

/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
static void
initLcdLowlevel(void)
{
  IODIR |= LCD_PWR;
  IOCLR  = LCD_PWR;

	IODIR |= (LCD_D4 | LCD_D5 | LCD_D6 | LCD_D7 | LCD_E | LCD_RS);
	IOCLR  = (LCD_D4 | LCD_D5 | LCD_D6 | LCD_D7 | LCD_E | LCD_RS);

  IODIR |= LCD_PWM;
  IOCLR  = LCD_PWM;

  osSleep(2);
  IOSET  = LCD_PWR;
  osSleep(10);

  //function set
  writeNibbleLCD(0x30);
  osSleep(1);
  writeNibbleLCD(0x30);
  osSleep(1);
  writeNibbleLCD(0x30);
  osSleep(1);
  writeNibbleLCD(0x20);  //4-bit interface
  osSleep(1);

  //function set
  writeLCD(0, 0x28); //4-bit interface
  delay37us();

  //display off
  writeLCD(0, 0x08);
  delay37us();

  //display clear
  writeLCD(0, 0x01);
  osSleep(1); //actually only 1.52 mS needed
      
  //display control set
  writeLCD(0, 0x06);
  osSleep(1);

  //display control set
  writeLCD(0, 0x0c);
  delay37us();

  //cursor home
  writeLCD(0, 0x02);
  osSleep(1);
}


/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
void
initLcd(void)
{
  initLcdLowlevel();

  osSemInit(&lcdSem, 0);
  executeLcdReady = TRUE;
}

/*****************************************************************************
 *
 * Description:
 *    xxx
 *
 ****************************************************************************/
void
handleLcd(void)
{
  tU8 error;

  for(;;)
	{
		//wait for semaphore
    osSemTake(&lcdSem, 0, &error);
		
		//execute command string
    executeCommandString(pPendingCommandString);
    executeLcdReady = TRUE;
	}
}

