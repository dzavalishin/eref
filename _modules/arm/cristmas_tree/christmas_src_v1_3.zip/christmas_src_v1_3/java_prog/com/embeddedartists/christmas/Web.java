package com.embeddedartists.christmas;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Vector;
import java.util.Random;

public class Web {
	
	private static final String URL_USERS 
	= "http://www.embeddedartists.com/support/ctree.php?c=1";
	
	private static final String URL_MESSAGES 
	= "http://www.embeddedartists.com/support/ctree.php?c=2";
	
	private static final String URL_PRIO_MESSAGE 
	= "http://www.embeddedartists.com/support/ctree.php?c=3";
	
	private static String uid = null;
	private static String uidArg = null;
	
	static {
		
		// create a unique ID so that several users on the same network
		// won't be identified as one user
		
		try {
			InetAddress localHost = InetAddress.getLocalHost();
			uid = localHost.getHostAddress();
		} catch (UnknownHostException e) {
			Debug.debug("Web.<static>", "Failed to get local host: "+e);
		}
		
		if (uid == null || uid.trim().length() == 0) {
			int rand = new Random().nextInt(Integer.MAX_VALUE);
			
			uid = Integer.toString(rand);
		}
		
		uidArg = "&uid="+uid;		
	}
	
	/**
	 * Get number of online users
	 * @return number of online users or -1 in case of failure
	 */
	public static int getNumberOfUsers() {
		URL url = null;
		int num = -1;
		
		try {
			url = new URL(URL_USERS+uidArg);		

            BufferedReader input = new BufferedReader(
            		new InputStreamReader(url.openStream()));

            while(num == -1)
            {
                String data = input.readLine();
                            
                // EOF
                if (data == null)                
                	break;
                
                data = data.trim();
                
                if (data.length() > 0) {
                	try {
                		num = Integer.parseInt(data);
                	} catch(NumberFormatException nfe) {                		
                	}
                }
            }
			
			
		} catch (MalformedURLException e) {
			Debug.debug("Web.getNumberOfUsers", "Malformed URL: "+e);
		} catch (IOException ioe) {
			Debug.debug("Web.getNumberOfUsers", ""+ioe);
		}
				
		return num;
	}
	
	
	/**
	 * Get latest messages
	 * @return latest messages
	 */	
	public static String[] getLatestMessages() {
		URL url = null;
		String[] msgs = null;
		Vector store = new Vector();
		
		try {
			url = new URL(URL_MESSAGES+uidArg);		

            BufferedReader input = new BufferedReader(
            		new InputStreamReader(url.openStream()));

            while(true)
            {
                String data = input.readLine();
                            
                // EOF
                if (data == null)                
                	break;
                
                data = data.trim();
                
                if (data.length() > 0) {
            		store.add(data);
                }
            }
			
			
		} catch (MalformedURLException e) {
			Debug.debug("Web.getLatestMessages", "Malformed URL: "+e);
		} catch (IOException ioe) {
			Debug.debug("Web.getLatestMessages", ""+ioe);
		}
		
		msgs = new String[store.size()];
		store.copyInto(msgs);
		
		return msgs;
	}
	
	/**
	 * Get prioritized message
	 * @return prioritized message or null in case of failure or none available
	 */
	public static String getPrioMessage() {
		URL url = null;
		String msg = null;
		
		try {
			url = new URL(URL_PRIO_MESSAGE+uidArg);		

            BufferedReader input = new BufferedReader(
            		new InputStreamReader(url.openStream()));

            while(msg == null)
            {
                String data = input.readLine();
                            
                // EOF
                if (data == null)                
                	break;
                
                data = data.trim();
                
                if (data.length() > 0) {
            		msg = data;
                }
            }			
			
		} catch (MalformedURLException e) {
			Debug.debug("Web.getPrioMessage", "Malformed URL: "+e);
		} catch (IOException ioe) {
			Debug.debug("Web.getPrioMessage", ""+ioe);
		}
				
		return msg;
	}
}
