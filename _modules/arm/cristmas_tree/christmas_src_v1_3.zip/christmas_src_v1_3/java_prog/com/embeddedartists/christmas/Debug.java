package com.embeddedartists.christmas;

public class Debug {
	
	private static boolean debug = false;
	
	public static void useDebug() {
		debug = true;
	}
	
	public static void debug(String origin, String msg) {
		if(debug)
			System.out.println("## "+origin+": "+msg);
	}
}
