package com.embeddedartists.christmas;

import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gnu.io.UnsupportedCommOperationException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.TooManyListenersException;
import java.util.Vector;

public class Device implements SerialPortEventListener {
	
	/*
	 * Error codes returned from the connect method
	 */
	
	/** Device is connected */
	public static final int CONNECTED     = 0;
	/** A port must be chosen (use connect(String port)) */
	public static final int CHOOSE_PORT   = 1;
	/** Port is already in use */
	public static final int PORT_IN_USE   = 2;
	/** The port does not exist */
	public static final int NO_SUCH_PORT  = 3;
	/** Device could not be connected */
	public static final int NOT_CONNECTED = 4;
		
	/*
	 * Settings
	 */	
	
	/** Baud rate */
	private static final int BAUD_RATE = 57600;
	/** How often the monitor should ping to device to see if it is alive */
	private static final long MONITOR_TIME = 5000;

	/*
	 * Commands sent to and from device
	 */

	/** Ping command, used to see if the device is alive */
	private static final int CMD_PING      = 0xF4;
	/** Notify device of number of online users */
	private static final int CMD_USERS     = 0xF0;
	/** Notify device with a message */
	private static final int CMD_MSG       = 0xF1;
	/** Notify device with a prioritized message */
	private static final int CMD_PRIO      = 0xF2;
	/** Check if device is ready to receive message */
	private static final int CMD_READY     = 0xF3;
	
	
	/** Used to protect the serial port (input and output streams) */
	private final Object mutex = new Object();	
	
	/** Serial port used to connect to device */
	private SerialPort   port = null;
	/** Input from device */
	private InputStream  input = null;
	/** Output to device */
	private OutputStream output = null;	
	/** Monitoring the device (to see if it is alive) */
	private Monitor      monitor = null;
	/** Device listener */
	private DeviceListener listener = null;
	
	/**
	 * Constructor
	 * @param listener device listener
	 */
	public Device(DeviceListener listener) {
		this.listener = listener;
	}
	
// ------------------------------------------------------------- PUBLIC METHODS
	
	/**
	 * Connect to the device.
	 * 
	 * @return CONNECTED     - successfully connected to device.
	 *         CHOOSE_PORT   - more than one port is available, choose one.
	 *         PORT_IN_USE   - the port is already in use.
	 *         NO_SUCH_PORT  - the port does not exist.
	 *         NOT_CONNECTED - couldn't connect to device.
	 */
	public int connect() {
		int numSerialPorts = 0;
		CommPortIdentifier portIdent = null;
		Enumeration en = CommPortIdentifier.getPortIdentifiers();
		
		while(en.hasMoreElements()) {
			CommPortIdentifier ci = (CommPortIdentifier) en.nextElement();
			
			if (/*true */ci.getPortType() == CommPortIdentifier.PORT_SERIAL) {
				if (++numSerialPorts > 1) {
					break;
				}
				
				portIdent = ci;
			}
		}
		
		if (numSerialPorts == 0) {
			return NOT_CONNECTED;
		}
		
		if (numSerialPorts == 1) {
			return connect(portIdent.getName());					
		}		
		
		Debug.debug("Device.connect", "Too many ports: "+numSerialPorts);
		
		return CHOOSE_PORT;
	}
	
	/**
	 * Connect to the device by specifying a port name.
	 * 
	 * @param comPort name of port
	 * @return CONNECTED     - successfully connected to device.
	 *         CHOOSE_PORT   - more than one port is available, choose one.
	 *         PORT_IN_USE   - the port is already in use.
	 *         NO_SUCH_PORT  - the port does not exist.
	 *         NOT_CONNECTED - couldn't connect to device.
	 */	
	public int connect(String comPort) {
		CommPortIdentifier ci = null;
		int errorCode = NOT_CONNECTED;
		
		Debug.debug("Device.connect", "connecting to "+comPort);
		
		try {
			ci = CommPortIdentifier.getPortIdentifier(comPort);
			
			if (ci.getPortType() == CommPortIdentifier.PORT_SERIAL) {							
				port = (SerialPort) ci.open("ChristmasTree", 2000);							
				port.setSerialPortParams(BAUD_RATE, 
						SerialPort.DATABITS_8,
						SerialPort.STOPBITS_1, 
						SerialPort.PARITY_NONE);
 				port.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
								
				port.enableReceiveTimeout(5000);
				//port.notifyOnDataAvailable(true);
				//port.notifyOnOutputEmpty(true);
				port.addEventListener(this);
				
				input  = port.getInputStream();
				output = port.getOutputStream();							

				port.setDTR(false);
				port.setRTS(false);

				Debug.debug("Device.connect", "ReceiveTimeout supported: "
						+port.isReceiveTimeoutEnabled());


								
				if (ping())	{		
					errorCode = CONNECTED;
					monitor = new Monitor();
					new Thread(monitor).start();
				}
				else {					
					port.close();
					Debug.debug("Device.connect", "Failed to connect");					
				}																			
			}			
		} catch (NoSuchPortException ne) {
			Debug.debug("Device.connect", "no such port "+ne.getMessage());
			errorCode = NO_SUCH_PORT;
		} catch (PortInUseException pe) {
			Debug.debug("Device.connect", "port in use "+pe.getMessage());
			errorCode = PORT_IN_USE;
		} catch (TooManyListenersException e) {
		} catch (UnsupportedCommOperationException e) {
		} catch (IOException ioe) {
		}
		
		return errorCode;
	}
	
	/**
	 * Get names of available ports
	 * @return available ports
	 */
	public String[] getAvailablePorts() {
		Enumeration en = CommPortIdentifier.getPortIdentifiers();
		Vector ports = new Vector();
		
		while(en.hasMoreElements()) {
			CommPortIdentifier ci = (CommPortIdentifier) en.nextElement();			
			
			if (/*true*/ci.getPortType() == CommPortIdentifier.PORT_SERIAL) {
				ports.add(ci.getName());
			}
		}
		
		String[] portNames = new String[ports.size()];
		ports.copyInto(portNames);
		
		return portNames;
	}
	
	/**
	 * Notify device of number of online users
	 * @param num number of online users
	 * @return true if notification successful
	 */
	public boolean notifyNumberOfUsers(int num) {
		String msg = Integer.toString(num);

		return sendMessage(CMD_USERS, msg.getBytes());			
	}
	
	/**
	 * Notify device with a message
	 * @param the message to send to the device
	 * @return true if notification successful
	 */	
	public boolean notifyMessage(String msg) {
		if (msg != null && msg.length() > 0)
			return sendMessage(CMD_MSG, msg.getBytes());
		
		return false;
	}
	
	/**
	 * Notify device with a prio message
	 * @param the message to send to the device
	 * @return true if notification successful
	 */	
	public boolean notifyPrioMessage(String msg) {
		if (msg != null && msg.length() > 0)
			return sendMessage(CMD_PRIO, msg.getBytes());
		
		return false;		
	}
	
	/**
	 * Check if device is ready to receive a message
	 * @return true if ready; otherwise false
	 */
	public boolean isReadyForMessage() {
		return sendMessage(CMD_READY, null);
	}
	
	/**
	 * Close connection to device
	 */	
	public synchronized void close() {
		port.close();
		try {
			input.close();
			output.close();
		} catch(IOException ioe){			
		}
		
		monitor.closeMonitor();		
	}

	/**
	 * Serial port listener callback 
	 */
	public void serialEvent(SerialPortEvent ev) {
		Debug.debug("Device.serialEvent", "Type = "+ev.getEventType());
	}
	
// ------------------------------------------------------------ PRIVATE METHODS	
	
	/**
	 * Ping the device to see if it is alive
	 * @return true if device responded.
	 */	
	private boolean ping() {
		try {
			// empty the input buffer
			int data = 0;	
			do {
				data = input.read();
			} while(data != -1);		
		} catch(Exception e) {}		
		
		return sendMessage(CMD_PING, null);
	}
	
	/**
	 * Send a generic message to the device
	 * @param cmd command
	 * @param msg message
	 * @return true if message could be sent to device
	 */
	private boolean sendMessage(int cmd, byte[] msg) {
		int data = -1;
				
		if (input != null && output != null) {
			try {
				synchronized(mutex) {
					output.write(cmd);
					if(msg != null) {
						output.write(msg.length);
						output.write(msg);
					}
					data = input.read();
				}
			} catch (IOException ioe) {
				Debug.debug("Device.sendMessage", "Exc: "+ioe);
			}
		}		
		
		if(data != cmd)
			Debug.debug("Device.sendMessage", "data = "+data+" cmd = "+cmd);
		
		return (data == cmd);		
	}
	

//----------------------------------------------------------------- INNER CLASS
	
	/**
	 * This class monitors the device to see if it is alive. 
	 */
	class Monitor implements Runnable {
		private boolean closed = false;
		
		public void run() {
			try {
				while(!closed) {
					Thread.sleep(MONITOR_TIME);
					
					if(!ping()) {
						Debug.debug("Monitor.run", "No response from device -> closing down");
						UserInteraction.info("Device has been disconnected");
						
						close();						
						if(listener != null)
							listener.deviceClosed();
					}
				}
			} catch(InterruptedException ie) {
				Debug.debug("Monitor.run", "Interrupted: "+ie);
			}
		}
		
		/**
		 * Close the monitor
		 */
		public void closeMonitor() {
			closed = true;
		}
	}
}
