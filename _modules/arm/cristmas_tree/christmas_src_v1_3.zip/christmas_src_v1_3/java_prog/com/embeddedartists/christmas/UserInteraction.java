package com.embeddedartists.christmas;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



public class UserInteraction {

	/**
	 * Ask user to select an option
	 * @param msg message to present to the user
	 * @param options the options to choose from
	 * @return the selected option or -1 if selection aborted
	 */
	public static int select(String msg, String[] options) {
		String input = null;
		int    index = -1;
		
		System.out.println();
		System.out.println("  "+msg);
		underline("  ".length(), msg);
		for(int i = 0; i < options.length; i++) {
			System.out.println("  "+i+": "+options[i]);
		}
		
		System.out.print("  < ");
		
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in)); 
			input = br.readLine();
		}catch(IOException ioe) {
			Debug.debug("UserInteration.select", "Error reading input: "
					+ ioe.getMessage());
		}
		
		if (input != null) {
			try {
				index = Integer.parseInt(input);
			} catch(NumberFormatException nfe) {
				Debug.debug("UserInteration.select", "Not an integer: "+input);
			}
		}
									
		return index;
	}

	/**
	 * Present some information to the user.
	 * @param msg the information to present
	 */
	public static void info(String msg) {
		System.out.println("> "+msg);
	}
	
// ------------------------------------------------------------ PRIVATE METHODS
	
	/**
	 * Underline a string
	 * @param indent number of spaces to indent the underline
	 * @param s the string to underline
	 */
	private static void underline(int indent, String s) {
		
		for(int i = 0; i < indent; i++)
			System.out.print(" ");
		for(int i = 0; i < s.length(); i++)
			System.out.print("-");
		System.out.println();
	}
}
