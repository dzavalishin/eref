package com.embeddedartists.christmas;

import java.util.Vector;

public class Main implements DeviceListener{

	private static final int DISCONNECTED = 0;
	private static final int CONNECTED    = 1;
	
	/** interval between calls to get online users */
	private static final long INTERVAL_GET_USERS = 241000;
	/** interval between calls to get messages */
	private static final long INTERVAL_GET_MSG = 300000; 
	/** interval between calls to get prio message  */
	private static final long INTERVAL_GET_PRIO = 200000;
	
	/** Try to send a message too device at most every second minute */
	private static final long MESSAGE_TIME = 120000;
	
	private static final long SLEEP_TIME = 10000;
	
	private Device device = null;
	private int state = DISCONNECTED;
	private Thread mainThread = null;
	private long lastUsersTime = 0;
	private long lastMsgTime   = 0;
	private long lastPrioTime  = 0;
	
	private int      numUsers    = 0;
	private String[] messages    = null;
	private String   prioMessage = null;
	
	private MessageStore messageStore = null;
	private MessageScheduler msgScheduler = null;
	
	/**
	 * Constructor
	 */
	public Main() {
		device = new Device(this);
		messageStore = new MessageStore();
		msgScheduler = new MessageScheduler();
		new Thread(msgScheduler).start();
	}	
	
// ------------------------------------------------------------- PUBLIC METHODS
	
	/**
	 * Start the Christmas tree application
	 */
	public void start() {
		mainThread = Thread.currentThread();
		while(true) {
			if (state == DISCONNECTED) {				
				connectToDevice();
				state = CONNECTED;
				msgScheduler.deviceConnected(true);
			}
			else {
				long curr = System.currentTimeMillis();
				
				if (curr - lastUsersTime > INTERVAL_GET_USERS) {
					numUsers = Web.getNumberOfUsers();
					lastUsersTime = System.currentTimeMillis();
					UserInteraction.info("Number of connected users: "+numUsers);
					
					if(device.isReadyForMessage())
						device.notifyNumberOfUsers(numUsers);
				}
				
				if (curr - lastMsgTime > INTERVAL_GET_MSG) {
					messages = Web.getLatestMessages();
					lastMsgTime = System.currentTimeMillis();
					

					if (messages != null) {
						
						Debug.debug("Main.start", "Number of messages: "+messages.length);
						
						for (int i = 0; i < messages.length; i++) {
							Debug.debug("Main.start", i+": "+messages[i]);
							int idx = messages[i].lastIndexOf(' ');
							String msg   = messages[i].substring(0, idx); 
							String tsStr = messages[i].substring(idx+1);						
							
							messageStore.addMessage(
									new Message(msg, Integer.parseInt(tsStr)));
						}
					}
					
				}
				
				if (curr - lastPrioTime > INTERVAL_GET_PRIO) {
					prioMessage = Web.getPrioMessage();
					lastPrioTime = System.currentTimeMillis();
					
					Debug.debug("Main.start", "Prio Message: "+prioMessage);
					
					if(prioMessage != null && device.isReadyForMessage())
						device.notifyPrioMessage(prioMessage);
				}
				
				// sleep
				try {
					Thread.sleep(SLEEP_TIME);
				} catch(InterruptedException ie) {		
				}				
			}								
		}		
	}
	
	/**
	 * Device listener callback. Called when the device connection has
	 * been closed.
	 */
	public void deviceClosed() {
		state = DISCONNECTED;
		msgScheduler.deviceConnected(false);
		if(mainThread != null) {
			try {
				mainThread.interrupt();
			}catch(SecurityException se) {
				Debug.debug("Main.deviceClosed", ""+se);
			}
		}
	}
	
//	 ----------------------------------------------------------------------- Main
	
	/**
	 * Connect to the device
	 */
	private void connectToDevice() {
		UserInteraction.info("Connecting to device...");
		
		int result = device.connect();		
		do {
			
			if(result == Device.CHOOSE_PORT) {
				String[] ports = device.getAvailablePorts();
				int num = UserInteraction.select("Select which port to use", ports);
				if (num >= 0 && num < ports.length)
					result = device.connect(ports[num]);
				else
					UserInteraction.info("Connect attempt aborted");				
			}
			
			if(result != Device.CONNECTED) {
				UserInteraction.info("Connect attempt failed");
			}
			
			// if we fail to connect we wait a few seconds before trying again
			try {
				if (result != Device.CONNECTED) {
					Thread.sleep(2000);
					result = device.connect();
				}				
			} catch (InterruptedException e) {
			}
								
			// continue to try to connect until we are connected
		} while(result != Device.CONNECTED);
		
		UserInteraction.info("Device connected");
	}	
	
// ----------------------------------------------------------------------- Main
	
	/**
	 * main method 
	 */
	public static void main(String[] args) {
		
		if (args.length > 0) {
			Debug.useDebug();
			UserInteraction.info("Using debug mode");
		}
		
		Main m = new Main();
		m.start();		
	}
	
// -------------------------------------------------------------- INNER CLASSES	
	
	class Message {
		private boolean displayed = false;
		private String  message   = null;
		private int     timestamp = 0;
		
		public Message(String msg, int timestamp) {
			this.message = msg;
			this.timestamp = timestamp;
		}
		
		public boolean hasBeenDisplayed() {
			return displayed;
		}
		
		public void displayed() {
			displayed = true;
		}
		
		public String getMessage() {
			return message;
		}
		
		public boolean equals(Object o) {
			Message m = (Message)o;
				
			return  (m.message.equals(message) && m.timestamp == timestamp);
		}
	}
	
	
	class MessageStore {
		private static final int MAX_MESSAGES = 20;
		
		private Vector store = new Vector(MAX_MESSAGES);
		
		public void addMessage(Message msg) {
			synchronized(store) {
											
				/*
				 * Try to remove the oldest displayed message in case the store
				 * is full.
				 */
				if(!store.contains(msg) && store.size()  >= MAX_MESSAGES)
					removeOldest();
				
				/*
				 * Only store a message if there is room for it. If the store
				 * is full we don't store the message now, but will probably
				 * download it again next time we contact the server.
				 */
				if(!store.contains(msg) && store.size() < MAX_MESSAGES) {
					Debug.debug("MessageStore.addMessage: ",msg.getMessage());
					store.add(msg);
				}
			}
		}
		
		/**
		 * Get size of store, i.e., number of non displayed messages
		 * @return size
		 */
		public int size() {
			int num = 0;
			synchronized(store) {
				for(int i = 0; i < store.size(); i++) {
					if(!((Message)store.elementAt(i)).hasBeenDisplayed())
						num++;
				}
			}
			
			return num;			
		}
		
		public Message getNextMessage() {
			Message m = null;
			synchronized(store) {
				for(int i = 0; i < store.size(); i++) {
					m = (Message)store.elementAt(i);
					if (!m.hasBeenDisplayed()) {
						return m;
					}
				}
			}
			
			return null;
		}
		
		/**
		 * Remove the oldest and displayed message from the store
		 */
		private void removeOldest() {
			synchronized(store) {
				Message m = (Message)store.elementAt(0);
				if(m.hasBeenDisplayed()) {
					store.remove(0);
				}				
			}
		}
	}
	
	/**
	 * This class monitors the device to see if it is alive. 
	 */
	class MessageScheduler implements Runnable {
		private boolean closed = false;
		private boolean connected = false;
		
		public void run() {
			try {
				while(!closed) {
					Thread.sleep(MESSAGE_TIME);
					
					if(connected && messageStore.size() > 0 
							&& device.isReadyForMessage()) {
						
						
						Message m = messageStore.getNextMessage();
						if(device.notifyMessage(m.getMessage())) {
							m.displayed();
							Debug.debug("MessageScheduler.run", "Message sent: "
									+m.getMessage());
						}


					}
				}
			} catch(InterruptedException ie) {
				Debug.debug("MessageScheduler.run", "Interrupted: "+ie);
			}
		}
		
		/**
		 * Close the monitor
		 */
		public void close() {
			closed = true;
		}
		
		public void deviceConnected(boolean connected) {
			this.connected = connected;
		}
	}	
	
}
