package com.embeddedartists.christmas;

public interface DeviceListener {
	public void deviceClosed();
}
