PC-Program (Java)
-----------------

The PC Program is written in Java and is used to connect the Christmas tree
to the Internet. When the device is connected to the PC program and the PC
program is connected to the Internet, holiday greetings from other online
Christmas tree users can be downloaded to the LCD on the Christmas tree.

- Running build.bat will build the PC program. The java compiler 
  (javac) must be available in the search path.

- Running run.bat will start the PC program.


Christmas tree control application (c code)
-------------------------------------------

The code that controls the Christmas tree is located in the c_prog directory.

- To build the christmas tree application first start the QuickStart Build
  Environment and change the working directory to <your path>/c_prog/testProgram_ChristmasTree.
  Type "make" to build the project and "make deploy" to download the build
  to the target. 

  Please read the QuickStart Program Development User's Guide 
  for more detailed instructions of which tools you need and what you need
  to do in order to build a project.
  Specifically, you have to update the makefile for the correct COM-port that the
  USB-to-serial bridge use.
  
  When compiling for the LPC2103 version (from 2005), make sure the Make-files are set correct, i.e.
  CPU_VARIANT = LPC2103. Do not forget to change the Makefile in the "testProgram_ChristmasTree"
  directory as weel as in the "startup" directory.
  Also change the setting in the file "boardVersion.h".
  
