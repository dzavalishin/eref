// File Description:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// CAN_Example to test basic functions developed by Tobias Mueller. For feedback or questions: toby.cs@gmx.de
// You may use this software for your own non-commercial project! 
// Pay attention: This software can cause serious errors. Do only use this software in connection with a PC. Do not use it in your car
// or elsewhere. You could do serious damage to your environment!!
//
// This is designed for the Crumb128CAN (AT90CAN128)! BE SURE TO WRITE CKSEL FUSE TO 0xFF! The internal 8MHz oszillator is not precise enough
// to drive the CAN!!! In MAIN() the internal CLK-prescaler ist disabled to 1! Errorframes will result from bad bittiming! 
//
// The CAN-Bus will be initialized with a baudrate of 100kbit/s. Be sure to terminate both endings of your wiring with a 100ohm-resistor.
// If your wiring is all correct, you can go faster (up to 1Mbit/s) if your external transciever can cope.
// The function of this file is to receive a CAN-message with ID 0x14a and to reply with ID 0x14b.
// 
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

#define NOMOB 	0xff 	//!< return value for getmob()
#define RTR		0xff 	//!< special value for length ->RTR packet

#include <avr/interrupt.h>
#include <avr/io.h>
#include <avr/interrupt.h>





// Globals:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
volatile int msg_index=0;						//uart rx index
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


// FUNCTION Prototypes::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
void prepare_rx( char mob, unsigned id, unsigned idmask);
void can_tx( char mob, unsigned id, char length, char *data);
void can_init( void);
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


// global Structur to be used for any I/O::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
struct mob_struct
	{
		char active;
		unsigned char msg[8];
		int id;
		struct signals
			{
				char zeile;			//used for LCD OUTPUT
				char *name[8];
				char *unit[4];
				int sign;
				signed int scaling;
				int sb;			//startbit
				int length;
			}signal;
	} volatile mob[15];




// Helper to find out the mob::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// CANSIT Register passes the active MOB-Interrupts...
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
inline char getmob( unsigned bitmask);
inline char getmob( unsigned bitmask) 
{
	char mob;
	if( bitmask==0)return NOMOB;
	for( mob=0; (bitmask & 0x01)==0; bitmask >>= 1, ++mob);
	return mob;
}	


// CAN ISR::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
ISR(CANIT_vect)
{
	char i;
	char length;
	char cptemp=CANPAGE;					//to store the CANPAGE
	char mobnum=getmob( CANSIT2 | (CANSIT1 << 8));		//gets the interrupting mob
	CANPAGE = mobnum << 4;					//set the new CANPAGE
	length=CANCDMOB & 0x0f;					//Aquire the length
	for (i = 0; i <length; ++i)
		{
			mob[mobnum].msg[i]=CANMSG;			//sets the message to appropriate byte in structre "mob_structur"
		}
	CANSTMOB=0;							// reset origin of irpt
	CANCDMOB=0x80;						// re-enable RX ont this channel
	CANPAGE=cptemp;						// restore CANPAGE
	//reply on received frame
	can_tx(2,0x14b,8,"RX is ok");
}


// CAN TX Rountine::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// Be very careful: This has not been approved for road use!
// 
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
can_tx( char mob, unsigned id, char length, char *data)
{
	char cnt;
	char cptemp;
	cptemp = CANPAGE;
	CANPAGE = mob << 4;
	CANSTMOB = 0x00;    	// cancel pending operation 
	CANCDMOB = 0x00;
	if( length!=RTR)
		{
			CANIDT1=id >>3;
			CANIDT2=id <<5;
			CANIDT3=0x00;
			CANIDT4=0x00;
			CANIDM4=0xff;
			CANIDM3=0xff;
			CANIDM2=0xff;
			CANIDM1=0xff;
			for (cnt=0; cnt < length; ++cnt)CANMSG = data[cnt];         
			CANCDMOB|=length;
		}
		else
		{
			CANIDT1=id >>3;
			CANIDT2=id <<5;
			CANIDT3=0x00;
			CANIDT4 = 1<<RTRTAG;
			CANIDM4=0xff;
			CANIDM3=0xff;
			CANIDM2=0xff;
			CANIDM1=0xff;
			CANCDMOB|=length;
		}
		CANCDMOB|=0x40; //enable TX
		CANPAGE = cptemp;
	}


// RX-Setup Rountine::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// This sets up a MOB to receive a Message. The interrupt Rountine will start on reception of a new frame.
// Errors on the Bus do not generate an interrupt thus the errorcounters (CANREC &CANTEC) will overflow. This causes the Bus to go passive!
// Errorhandling needs to be employed on further steps...
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
prepare_rx( char mobnum, unsigned id, unsigned idmask)
{
	cli();							//disable global interrupts
	char cptemp;
	cptemp = CANPAGE;					// save old CANPAGE to restore
	CANPAGE = mobnum << 4;				// select new CANPAGE
	CANSTMOB = 0x00;   			 		// cancel pending operation 
	CANCDMOB = 0x00;					// disable MOB	
	CANIDT1=id >>3;					// set ID
	CANIDT2=id <<5;					// set ID
	CANIDT3=0x00;						// clear Remotereqest
	CANIDT4=0x00;						// clear Remotereqest
	CANIDM4=0xff;						// set no mask
	CANIDM3=0xff;						// set no mask		
	CANIDM2=0xff;						// set no mask
	CANIDM1=0xff;						// set no mask
	CANCDMOB=0x80; 					// enables RX! This has to be the very last command in setting the mobs most important parts!!! 
	CANIE2 |= (1<<mobnum);				// enable MOB-interrupt
	if (mobnum >8) CANIE1 |= (1<<(mobnum-8));	// enable MOB-interrupt
	CANPAGE = cptemp;					// restore CANPAGE
	sei();							// enable the interrupts
}


// RX-Setup Rountine:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// This sets up the CAN-Controller.
// Errors on the Bus do not generate an interrupt thus the errorcounters (CANREC &CANTEC) will overflow. This causes the Bus to go passive!
// Errorhandling needs to be employed on further steps...
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
void can_init( void)
{
	unsigned mob;
	CANGCON |= 0x01;					// CAN: Reset
	CANGCON |= 0x00;					// CAN: OFF
	CANBT1=0x12;						// Baudratesetting: for 100kbit/s: 0x12;for 500kbit/s: 0x02;for 1Mbit/s: 0x02;
	CANBT2=0x0c;						// Baudratesetting: for 100kbit/s: 0x0c;for 500kbit/s: 0x0c;for 1Mbit/s: 0x04;
	CANBT3=0x37;						// Baudratesetting: for 100kbit/s: 0x37;for 500kbit/s: 0x37;for 1Mbit/s: 0x13;
	for (mob = 0; mob < 15; mob++)			// clear every MOB
	{
		CANPAGE  = (mob << 4);
		CANSTMOB = 0x00;
		CANCDMOB = 0x00;
	}
	CANGCON |= 0x02;
	CANGIE=(1<<ENIT) | (1<< ENRX) ;			//Enables only the named interrupts
	CANGCON |= 0x02;					//CAN: ON
}


// MAIN :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
// 
// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
int main (void)
{	
	unsigned long i;
	CLKPR = 0x80;			//Change System CLK-Prescaler to 1
	CLKPR = 0x00;			//Change System CLK-Prescaler to 1
	can_init();
	sei();	
	prepare_rx(1,0x14a,0xffff);
	while (1)
	{

	}
	//never goes here!
	return 0;			
}
