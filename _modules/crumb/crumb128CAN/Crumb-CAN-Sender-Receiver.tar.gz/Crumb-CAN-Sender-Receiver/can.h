/******************************************************************************
**
**      Author          : Michael Schulze (mschulze)
**
**      Device          : AT90CAN128
**
**      File name       : can.h
**      Description     : The file defines the message object structur and
**			  some function prototypes.
**
**      Repository-Tag  : $Id: can.h 82 2006-11-09 14:05:33Z mschulze $
**
******************************************************************************/

#ifndef __can_h__
#define __can_h__

struct MOb
{
	unsigned long id;
	unsigned char data [8];
};

void can_init (void);
void can_tx (struct MOb msg);
void can_rx (struct MOb msg);

#endif
