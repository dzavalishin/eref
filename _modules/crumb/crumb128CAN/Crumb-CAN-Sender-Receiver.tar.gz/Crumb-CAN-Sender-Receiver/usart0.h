/******************************************************************************
**
**	Author      	: Michael Schulze (mschulze)
**
** 	Device      	: AT90CAN128
**
**	File name   	: usart.h
**	Description 	: It defines some prototypes for the communication 
**			  via usart0.
**
**	Repository-Tag	: $Id: usart0.h 82 2006-11-09 14:05:33Z mschulze $ 
**
******************************************************************************/
#ifndef __usart0_h__
#define __usart0_h__

void usart0_init( unsigned int baudrate );
unsigned char usart0_receive( void );
void usart0_transmit( unsigned char data );
void usart0_transmit_string(char* p);

#endif
