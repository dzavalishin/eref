/**************************************************************************************
**
**	Author      	: Michael Schulze (mschulze)
**
** 	Device      	: AT90CAN128
**
**	File name   	: Crumb-CAN-Receiver.c
**	Description 	: The program try to receive a CAN message with ID 0x1. 
**			  If it receives this message, the LED will be switched 
**			  and it waits for next messages.
**
**	Repository-Tag	: $Id: Crumb-CAN-Receiver.c 82 2006-11-09 14:05:33Z mschulze $
**
***************************************************************************************/

#include <avr/io.h>
#include <stdlib.h>
#include "usart0.h"
#include "can.h"

// message to receive
struct MOb msg={0x1,{0,0,0,0,0,0,0,0}};

// toggle the LED on the Crumb-Board
#define toggleLED() (DDRB^=(1<<7))

int main(){
	// init usart on 19200 8N1 at 16 MHz cpu clock
        usart0_init(51); 
	// greet the world
	usart0_transmit_string("Hello World\n");
	// init the can interface
	can_init();

	while(1){
		// send can message
		can_rx(msg);

		toggleLED();
	}
}


