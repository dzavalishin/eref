/******************************************************************************
**
**	Author      	: Michael Schulze (mschulze)
**
** 	Device      	: AT90CAN128
**
**	File name   	: usart0.c
**	Description 	: It implements the usart0 functionality of the 
**			  device.
**
**	Repository-Tag	: $Id: usart0.c 82 2006-11-09 14:05:33Z mschulze $ 
**
******************************************************************************/

#include <avr/io.h>
#include "usart0.h"

/* Initialize UART */
void usart0_init( unsigned int baudrate )
{
	/* Set the baud rate */
	UBRR0H = (unsigned char) (baudrate>>8);                  
	UBRR0L = (unsigned char) baudrate;
	
	/* Enable UART receiver and transmitter */
	UCSR0B = ( ( 1 << RXEN0 ) | ( 1 << TXEN0 ) ); 
	
	/* Set frame format: 8N1 */
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
}


/* Read and write functions */
unsigned char usart0_receive( void )
{
	/* Wait for incomming data */
	while ( !(UCSR0A & (1<<RXC0)) );			                
	/* Return the data */
	return UDR0;
}

void usart0_transmit( unsigned char data )
{
	/* Wait for empty transmit buffer */
	while ( !(UCSR0A & (1<<UDRE0)) ); 			                
	/* Start transmittion */
	UDR0 = data; 			        
}

void usart0_transmit_string(char* p){
	while (*p)
		usart0_transmit(*p++);
}
