Hardware-Setup
--------------

Connect the boards with a CAN-transceiver like the 
Philips 82C250 (see Crumb-CAN-Connecting.pdf).


Software-Installation
------------

Connect the Crumb-Board to a stk200 and power.
In order to flash the Board with the receiver 
program you have to type 
	
	#:> make program PROGRAM=Crumb-CAN-Receiver

in your shell or you use the AVRStudio flashing 
capabilities.
In order to flash the other (sending) board you
have to connect like the first one and then do

	#:> make program PROGRAM=Crumb-CAN-Sender


Now you can connect the boards within a CAN-Network
and the LEDs are switching in a 0.5-1.5 cycle.
