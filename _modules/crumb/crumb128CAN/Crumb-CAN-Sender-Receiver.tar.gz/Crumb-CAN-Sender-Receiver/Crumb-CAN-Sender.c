/*************************************************************************************
**
**	Author      	: Michael Schulze (mschulze)
**
** 	Device      	: AT90CAN128
**
**	File name   	: Crumb-CAN-Sender.c
**	Description 	: The program sends CAN messages with ID 0x1 and switches
**			  the LED if the message was sent. Then the program waits 
**			  between 0.5 and 1.5 seconds and the cycle begins  once
**			  again.
**
**	Repository-Tag	: $Id: Crumb-CAN-Sender.c 82 2006-11-09 14:05:33Z mschulze $
**
**************************************************************************************/

#include <avr/io.h>
#include <stdlib.h>
#include "usart0.h"
#include "can.h"

// message to send
struct MOb msg={0x1,{0,0,0,0,0,0,0,0}}; 

// toggle the LED on the Crumb-Board
#define toggleLED() (DDRB^=(1<<7))

int main(){
	// init usart on 19200 8N1 at 16 MHz cpu clock
        usart0_init(51); 
	// greet the world
	usart0_transmit_string("Hello World\n");
	// init the can interface
	can_init();

	while(1){
		// send can message
	        can_tx(msg);

		toggleLED();

		// wait round between 0.5-1.5 seconds
		unsigned long h=800000+random()%1600000;
		while(--h)
			asm("nop\t");
	}
}


