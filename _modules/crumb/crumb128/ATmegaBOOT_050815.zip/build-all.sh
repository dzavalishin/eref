#!/usr/bin/bash

make clean
make PRODUCT=CRUMB8 AVR_FREQ=F14745600 all
make clean
make PRODUCT=CRUMB128 AVR_FREQ=F14745600 all
make clean
make PRODUCT=CRUMB168 AVR_FREQ=F20000000 all
make clean
make PRODUCT=PROBOMEGA128 AVR_FREQ=F14745600 all
make clean
make PRODUCT=SAVVY128 AVR_FREQ=F7372800 all
make clean
make PRODUCT=SAVVY128 AVR_FREQ=F8000000 all
make clean
make PRODUCT=SAVVY128 AVR_FREQ=F14745600 all
make clean
