

void ethernetTransmit(char *data,int len):
void ethernetReceive(char *data);
