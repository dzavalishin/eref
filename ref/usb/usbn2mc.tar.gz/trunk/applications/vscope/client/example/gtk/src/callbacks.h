#include <gtk/gtk.h>


void
on_btnopen_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnsetcountermode_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnstart_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnstop_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_btnreaddata_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn100us_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn1ms_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn5us_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_btn100ms_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_main_destroy_event                  (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);
