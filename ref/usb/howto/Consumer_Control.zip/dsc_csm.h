flash char STR_DATA[] = {4,3,9,4             //LANGID array (English) 

// MFG_STR --> "Audio Alliance Ltd" -----------------*/
     , 38,3,'A',0,'u',0,'d',0,'i',0,'o',0,' ',0,'A',0,'l',0,'l',0,'i',0
     , 'a',0,'n',0,'c',0,'e',0,' ',0,'L',0,'t',0,'d',0 

// PID_STR --> "Consumer Keys" ------------------------*/
     , 28,3,'C',0,'o',0,'n',0,'s',0,'u',0,'m',0,'e',0,'r',0,' ',0,'K',0,'e',0
     ,'y',0,'s ',0  

// NBR_STR --> "001" ---------------------------------*/
     , 8,3,'0',0,'0',0,'1',0
     };                

#define MFG_STR      1
#define PID_STR      2
#define SNBR_STR     3
#define CFG_STR      4
#define INT_STR      5

#define MFG_STR_L      38
#define PID_STR_L      28
#define SNBR_STR_L     8


flash char ReportDescriptor[45] = {
    0x05, 0x0c,                    // USAGE_PAGE (Consumer Devices)
    0x09, 0x01,                    // USAGE (Consumer Control)
    0xa1, 0x01,                    // COLLECTION (Application)
    0x15, 0x00,                    //   LOGICAL_MINIMUM (0)
    0x25, 0x01,                    //   LOGICAL_MAXIMUM (1)
    0x85, 0x01,                    //   REPORT_ID (1)
    0x09, 0xe9,                    //   USAGE (Volume Up)
    0x09, 0xea,                    //   USAGE (Volume Down)
    0x75, 0x01,                    //   REPORT_SIZE (1)
    0x95, 0x02,                    //   REPORT_COUNT (2)
    0x81, 0x02,                    //   INPUT (Data,Var,Abs)
    0x95, 0x06,                    //   REPORT_COUNT (6)
    0x81, 0x01,                    //   INPUT (Cnst,Ary,Abs)
    0x09, 0xb5,                    // USAGE (Scan Next Track)
    0x09, 0xb6,                    // USAGE (Scan Previous Track)
    0x09, 0xcd,                    // USAGE (Play/Pause)
    0x09, 0xb7,                    // USAGE (Stop)
    0x85, 0x02,                    // REPORT_ID (2)
    0x95, 0x04,                    //   REPORT_COUNT (4)
    0x81, 0x06,                    // INPUT (Data,Var,Rel)
    0x95, 0x04,                    // REPORT_COUNT (4)
    0x81, 0x01,                    //   INPUT (Cnst,Ary,Abs)
    0xc0                           // END_COLLECTION
};

#define RPT_DESC_SIZE  sizeof(ReportDescriptor)

flash char DEV_DESC[] = {DEV_LENGTH,        /*�������� ����� ����������� � ������         */
                         DEVICE,            /*��������� �� DEVICE descriptor              */
                         0x10,0x01,         /*������ USB ������������ � BCD  1.1          */
                         0x02,              /*��� ������ ����������  CDC                  */
                         0x00,              /*��� ��������� ���������� - unused � ����� 0 */
                         0x00,              /*��� ��������� - unused � ����� 0            */
                         0x08,              /*������ ������ ��� Endpoint 0                */
                         0x4B,0x53,         /*KS Labs Vendor ID  - 534B                   */
                         0x00,0x0A,         /*KS Labs Product ID - 0A00                   */
                         0x00,0x01,         /*KS Labs Revision ID 0.1 � BCD               */
                         MFG_STR,           /*������ ������������� � String Descriptor    */
                         PID_STR,           /*������ �������� � String Descriptor         */
                         SNBR_STR,          /*������ ��������� ������ � String Descriptor */
                         0x01               /*���������� ��������� ������������           */
                         };


flash char CFG_DESC[] = {CFG_LENGTH,        /*length of this desc.    */
                         CONFIGURATION,     /*CONFIGURATION descriptor*/
                         0x22,0x00,         /*total length returned   */
                         0x01,              /*number of interfaces    */
                         0x01,              /*number of this config   */
                         0,                 /*index of config. string */
                         0x80,              /*attr.: bus  powered     */
                         50,                /*max power (100 mA)      */

                         INT_LENGTH,        /*length of this desc.    */
                         INTERFACE,         /*INTERFACE descriptor    */
                         0x00,              /*interface number        */
                         0x00,              /*alternate setting       */
                         0x01,              /*# of (non 0) endpoints  */
                         HIDCLASS,          /*interface class         */
                         NOSUBCLASS,        /*interface subclass      */
                         0x00,              /*interface protocol      */
                         0,                 /*index of intf. string   */

                         HID_LENGTH,        /*length of this desc.    */
                         HID,               /*HID descriptor          */
                         0x00,0x01,         /*HID spec rev level (BCD)*/
                         0x00,              /*target country          */
                         1,                 /*# HID class desc follow.*/
                         HIDREPORT,         /*report descr. type      */
                         RPT_DESC_SIZE,0x00, /*report descr. length   */

                       /*Pipe 0 (endpoint 5)                          */
                         END_LENGTH,        /*length of this desc.    */
                         ENDPOINT,          /*ENDPOINT descriptor     */
                         0x85,              /*address (IN)            */
                         0x03,              /*attributes  (INTERRUPT) */
                         0x40,0x00,         /*max packet size (64)    */
                         0xFF};             /*interval (ms)           */

#define DEV_DESC_SIZE sizeof(DEV_DESC)
#define CFG_DESC_SIZE sizeof(CFG_DESC)
