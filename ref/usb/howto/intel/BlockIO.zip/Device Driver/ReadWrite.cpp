// BlockIO.sys read/write routines.  
//
// Derived from:
// Read/Write request processors for loopback driver
// Copyright (C) 1999 by Walter Oney
// All rights reserved

#include "stddcls.h"
#include "driver.h"

struct _RWCONTEXT : public _URB {
	ULONG_PTR va;				// virtual address for next segment of transfer
	ULONG length;				// length remaining to transfer
	PMDL mdl;					// partial MDL
	ULONG numxfer;				// cumulative transfer count
	BOOLEAN	NeedZeroPacket;		// TRUE if short packet needed to terminate a write  
	};

typedef struct _RWCONTEXT RWCONTEXT, *PRWCONTEXT;

NTSTATUS OnReadWriteComplete(PDEVICE_OBJECT fdo, PIRP Irp, PRWCONTEXT ctx);

///////////////////////////////////////////////////////////////////////////////
#pragma PAGEDCODE

NTSTATUS DispatchReadWrite(PDEVICE_OBJECT fdo, PIRP Irp) {
	PAGED_CODE();
	PDEVICE_EXTENSION pdx = (PDEVICE_EXTENSION) fdo->DeviceExtension;
	NTSTATUS status = IoAcquireRemoveLock(&pdx->RemoveLock, Irp);
	if (!NT_SUCCESS(status)) return CompleteRequest(Irp, status, 0);
	PIO_STACK_LOCATION stack = IoGetCurrentIrpStackLocation(Irp);
	BOOLEAN read = stack->MajorFunction == IRP_MJ_READ;
	
	USBD_PIPE_HANDLE hpipe = read ? pdx->hinpipe : pdx->houtpipe;
	LONG haderr;
	if (read) haderr = InterlockedExchange(&pdx->inerror, 0);
	else haderr = InterlockedExchange(&pdx->outerror, 0);
	if (haderr && !NT_SUCCESS(ResetPipe(fdo, hpipe))) ResetDevice(fdo);

// Our strategy will be to do the transfer in stages up to MAXTRANSFER bytes
// long using a single URB that we resubmit during the completion routine.
// Note that chained URBs via UrbLink are not supported in either Win98 or Win2K.
	PRWCONTEXT ctx = (PRWCONTEXT) ExAllocatePool(NonPagedPool, sizeof(RWCONTEXT));
	if (!ctx) {
		KdPrint((DRIVERNAME "Can't allocate memory for context structure\n"));
		IoReleaseRemoveLock(&pdx->RemoveLock, Irp);
		return CompleteRequest(Irp, STATUS_INSUFFICIENT_RESOURCES, 0);
		}
	RtlZeroMemory(ctx, sizeof(RWCONTEXT));

	ULONG length = Irp->MdlAddress ?  MmGetMdlByteCount(Irp->MdlAddress) : 0;
	KdPrint((DRIVERNAME "In DispatchReadWrite with Length = %8.8x (%d)\n", length, length));
	if (!length) {						// zero-length read
		IoReleaseRemoveLock(&pdx->RemoveLock, Irp);
		return CompleteRequest(Irp, STATUS_SUCCESS, 0);
		}
	ULONG_PTR va = (ULONG_PTR) MmGetMdlVirtualAddress(Irp->MdlAddress);
	ULONG urbflags =  USBD_SHORT_TRANSFER_OK | (read ? USBD_TRANSFER_DIRECTION_IN : USBD_TRANSFER_DIRECTION_OUT);

// Calculate the length of the segment we'll transfer in the first stage.
	ULONG seglen = length;
	if (seglen > pdx->maxtransfer) seglen = pdx->maxtransfer;

// Allocate an MDL for the first segment of the transfer.
	PMDL mdl = IoAllocateMdl((PVOID) va, pdx->maxtransfer, FALSE, FALSE, NULL);
	if (!mdl) {
		KdPrint((DRIVERNAME "Can't allocate memory for MDL\n"));
		ExFreePool(ctx);
		IoReleaseRemoveLock(&pdx->RemoveLock, Irp);
		return CompleteRequest(Irp, STATUS_INSUFFICIENT_RESOURCES, 0);
		}

// Initialize the (partial) MDL to describe the first segment's subset of the user buffer.
	IoBuildPartialMdl(Irp->MdlAddress, mdl, (PVOID) va, seglen);

	CSHORT oldfail = mdl->MdlFlags & MDL_MAPPING_CAN_FAIL;
	mdl->MdlFlags |= MDL_MAPPING_CAN_FAIL;
	if (!MmMapLockedPages(mdl, KernelMode)) {
		KdPrint((DRIVERNAME "Can't map memory for Read or Write\n"));
		ExFreePool(ctx);
		IoReleaseRemoveLock(&pdx->RemoveLock, Irp);
		return CompleteRequest(Irp, STATUS_INSUFFICIENT_RESOURCES, 0);
		}
	if (!oldfail) mdl->MdlFlags &= ~MDL_MAPPING_CAN_FAIL;

	UsbBuildInterruptOrBulkTransferRequest(ctx, sizeof(_URB_BULK_OR_INTERRUPT_TRANSFER),
		hpipe, NULL, mdl, seglen, urbflags, NULL);

	KdPrint((DRIVERNAME "First transfer is %8.8x bytes using buffer address %8.8x\n", seglen, va));

// Set context structure parameters to pick up where we will leave off
	ctx->va = va + seglen; ctx->length = length - seglen; ctx->mdl = mdl; ctx->numxfer = 0;

// Use the original Read or Write IRP as a container for the URB
	stack = IoGetNextIrpStackLocation(Irp);
	stack->MajorFunction = IRP_MJ_INTERNAL_DEVICE_CONTROL;
	stack->Parameters.Others.Argument1 = (PVOID) (PURB) ctx;
	stack->Parameters.DeviceIoControl.IoControlCode = IOCTL_INTERNAL_USB_SUBMIT_URB;

	IoSetCompletionRoutine(Irp, (PIO_COMPLETION_ROUTINE) OnReadWriteComplete, (PVOID) ctx, TRUE, TRUE, TRUE);
	IoMarkIrpPending(Irp);
	status = IoCallDriver(pdx->LowerDeviceObject, Irp);
	if (!NT_SUCCESS(status) && !NT_SUCCESS(ResetPipe(fdo, hpipe))) ResetDevice(fdo);

	return STATUS_PENDING;	
	}

///////////////////////////////////////////////////////////////////////////////
#pragma LOCKEDCODE

NTSTATUS OnReadWriteComplete(PDEVICE_OBJECT fdo, PIRP Irp, PRWCONTEXT ctx) {
	PDEVICE_EXTENSION pdx = (PDEVICE_EXTENSION) fdo->DeviceExtension;
	BOOLEAN read = (ctx->UrbBulkOrInterruptTransfer.TransferFlags & USBD_TRANSFER_DIRECTION_IN) != 0;
	ctx->numxfer += ctx->UrbBulkOrInterruptTransfer.TransferBufferLength;
	USBD_STATUS urbstatus = URB_STATUS(ctx);

	KdPrint((DRIVERNAME "Status=%8.8x,  %8.8x bytes were transferred\n", urbstatus, ctx->UrbBulkOrInterruptTransfer.TransferBufferLength));  
	
	if (!USBD_SUCCESS(urbstatus)) KdPrint((DRIVERNAME "%s failed with USBD status %X\n", read ? "Read" : "Write", urbstatus));

// If this stage completed without error, resubmit the URB to perform the next stage
	NTSTATUS status = Irp->IoStatus.Status;
	if (NT_SUCCESS(status) && ctx->length) {

// Calculate length of next stage of the transfer
		ULONG seglen = ctx->length;
		if (seglen > pdx->maxtransfer) seglen = pdx->maxtransfer;

// We're now in arbitrary thread context, so the virtual address of the user buffer is currently meaningless. 
// IoBuildPartialMdl copies physical page numbers from the original IRP's probed-and-locked MDL, however,
// so our process context doesn't matter.
		PMDL mdl = ctx->mdl;
		MmPrepareMdlForReuse(mdl);
		IoBuildPartialMdl(Irp->MdlAddress, mdl, (PVOID) ctx->va, seglen);
		CSHORT oldfail = mdl->MdlFlags & MDL_MAPPING_CAN_FAIL;
		mdl->MdlFlags |= MDL_MAPPING_CAN_FAIL;
		if (!MmMapLockedPages(mdl, KernelMode)) {	// can't map transfer segment
			KdPrint((DRIVERNAME "Can't map memory for Read or Write\n"));
			status = STATUS_INSUFFICIENT_RESOURCES;
			Irp->IoStatus.Status = STATUS_INSUFFICIENT_RESOURCES;	// okay to change because DispatchReadWrite returned STATUS_PENDING
			goto FinishCompletion;
			}
		if (!oldfail) mdl->MdlFlags &= ~MDL_MAPPING_CAN_FAIL;

// Reinitialize the URB
		ctx->UrbBulkOrInterruptTransfer.TransferBufferLength = seglen;

// The "next" stack location is the one belonging to the driver underneath us.
// It's been mostly set to zero and must be reinitialized.
		PIO_STACK_LOCATION stack = IoGetNextIrpStackLocation(Irp);
		stack->MajorFunction = IRP_MJ_INTERNAL_DEVICE_CONTROL;
		stack->Parameters.Others.Argument1 = (PVOID) (PURB) ctx;
		stack->Parameters.DeviceIoControl.IoControlCode = IOCTL_INTERNAL_USB_SUBMIT_URB;
		IoSetCompletionRoutine(Irp, (PIO_COMPLETION_ROUTINE) OnReadWriteComplete, (PVOID) ctx, TRUE, TRUE, TRUE);

		KdPrint((DRIVERNAME ">Next transfer is %8.8x bytes using buffer address %8.8x\n", seglen, ctx->va));

		ctx->va += seglen;
		ctx->length -= seglen;

// Pass the recycled IRP down and ignore the return code from IoCallDriver.
		IoCallDriver(pdx->LowerDeviceObject, Irp);
		return STATUS_MORE_PROCESSING_REQUIRED; // halt completion process in its tracks!
		}

// The request is complete now

FinishCompletion:			// label reached if MDL locking fails
	if (NT_SUCCESS(status)) Irp->IoStatus.Information = ctx->numxfer;
	else {					// had an error
		if (read) InterlockedIncrement(&pdx->inerror);
		else InterlockedIncrement(&pdx->outerror);
		KdPrint((DRIVERNAME "%s finished with error %X\n", read ? "Read" : "Write", status));
		}

	IoFreeMdl(ctx->mdl);
	ExFreePool(ctx);
	IoReleaseRemoveLock(&pdx->RemoveLock, Irp);

	return status;
	}
