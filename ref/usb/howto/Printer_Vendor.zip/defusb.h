
#define USB_DEFAULT                 0x00    /* No descriptor read*/
#define USB_DESCRIPTOR_READ         0x01    /* Descriptor read, Addr not assigned*/
#define USB_ADDRESS_ASSIGNED        0x02    /* Descriptor Read, Addr assigned*/
#define USB_CONFIGURED              0x03

/*GLOBAL STATUS VALUES*/
#define STD_COMMAND                 0x00
#define SETUP_COMMAND_PHASE         0x40
#define FUNCTION_ERROR              0x7F    /* Used when we are stalling the function EP0 */
#define HUB_ERROR                   0xFF    /* Used when we are stalling the HUB EP0 */

/*1.0 Request Values*/
#define GET_STATUS                  0x00
#define CLEAR_FEATURE               0x01
#define SET_FEATURE                 0x03
#define SET_ADDRESS                 0x05
#define GET_DESCRIPTOR              0x06
#define SET_DESCRIPTOR              0x07
#define GET_CONFIGURATION           0x08
#define SET_CONFIGURATION           0x09
#define GET_INTERFACE               0x0A
#define SET_INTERFACE               0x0B
#define SYNCH_FRAME                 0x0C

/*HID Request Values*/
#define GET_REPORT                  0x01
#define GET_IDLE                    0x02
#define GET_PROTOCOL                0x03
#define SET_REPORT                  0x09
#define SET_IDLE                    0x0A
#define SET_PROTOCOL                0x0B

/*CDC Request Values*/
#define SEND_ENCAPSULATED_COMMAND   0x00
#define GET_ENCAPSULATED_COMMAND    0x01
#define SET_LINE_CODING             0x20
#define GET_LINE_CODING             0x21
#define SET_CONTROL_LINE_STATE      0x22


/*Printer Request Values*/
#define GET_DEVICE_ID               0x00
#define GET_PORT_STATUS             0x01
#define SOFT_RESET                  0x02

/*Descriptor Types*/
#define DEVICE                      0x01
#define CONFIGURATION               0x02
#define XSTRING                     0x03
#define INTERFACE                   0x04
#define ENDPOINT                    0x05
#define HID                         0x21
#define HIDREPORT                   0x22
#define HIDPHYSICAL                 0x23
#define CS_INTERFACE                0x24
#define CS_ENDPOINT                 0x25 


/*Lengths of various descriptor segments*/
#define DEV_LENGTH                  18      /*length of device desc.  */
#define CFG_LENGTH                  9       /*length of cfg. desc. seg*/
#define INT_LENGTH                  9       /*length of int. desc. seg*/
#define HID_LENGTH                  9       /*length of HID  desc. seg*/
#define END_LENGTH                  7       /*length of end. desc. seg*/


/*Class codes*/
#define HIDCLASS                    0x03
#define NOSUBCLASS                  0x00
#define BOOTSUBCLASS                0x01
#define VENDORSPEC                  0xFF

/*Recipient Selectors/Masks*/
#define RECIPIENT_MASK              0x1F
#define DEVICE_RECIPIENT            0x00
#define INTERFACE_RECIPIENT         0x01
#define ENDPOINT_RECIPIENT          0x02
#define OTHER_RECIPIENT             0x03


/*Feature Selectors*/
#define DEVICE_REMOTE_WAKEUP        0x01
#define ENDPOINT_STALL              0x00

