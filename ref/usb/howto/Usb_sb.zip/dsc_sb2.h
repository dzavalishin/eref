flash char DEV_DESC[] = {0x12,          //Device Descriptor length 
                         0x01,          //DEVICE descriptor  
                         0x10,0x01,     //USB spec rev 1.1 (BCD)  
                         0x00,          //Device class            
                         0x00,          //Device subclass         
                         0x00,          //Device protocol         
                         0x08,          //Max packet size         
                         0x53,0x4B,     //KS Labs Vendor ID    
                         0x02,0x00,     //USB Audio Product ID   
                         0x03,0x01,     //USB Audio release number in BCD 
                         0x01,          //Index of manufacturer string  
                         0x02,          //Index of product  string  
                         0x03,          //Index of serial number string  
                         0x01           //Number of possible configurations
                         };

flash char CFG_DESC[] = {0x09,          //Configuration Descriptor length 
                         0x02,          //CONFIGURATION descriptor
                         0xAE,0x00,     //Total length returned   
                         0x03,          //Number of interfaces in this Configuration
                         0x01,          //Number of this Configuration
                         0x00,          //Index of configuration string - None
                         0x80,          //attrib - Bus  powered   
                         0xFA,          //Max power (2*250=500 mA)      

//Standart Audio Control Interface Descriptor

                         0x09,          //AC Interface length
                         0x04,          //INTERFACE descriptor Type   
                         0x00,          //Number of this interface
                         0x00,          //No Alternate settings
                         0x00,          //No status interrupt endpoint
                         Audio,         //Interface class - Audio        
                         AudioControl,  //Interface subclass - Audio Control
                         0x00,          //Interface protocol      
                         0x00,          //Index of interface String - None  

//Class-Specific Audio Control Inerface Descriptor

                         0x0A,          //AC CS interface length
                         CS_Interface,  //CS Inerface Descriptor Type
                         Header,        //Header Descriptor subtype
                         0x00,0x01,     //Audio Device Class Specification 1.1
                         0x34,0x00,     //Length reurned by AC Interface (Header+Unit+Terminal)
                         0x02,          //Number of AS inerfaces
                         0x01,          //AS interface ID for SB Line Out
                         0x02,          //AS interface ID for SB Line IN
 
//Input Terminal Descriptor for SB Line OUT

                         0x0C,          //Input Terminal Descriptor Length  
                         CS_Interface,  //CS Interface Descriptor Type
                         In_Terminal,   //Subtype - Input Terminal    
                         0x01,          //Terminal ID
                         0x01,0x01,     //Terminal Type - USB Streaming
                         0x00,          //Terminal Association - none      
                         0x01,          //Number of output chanels
                         0x00,0x00,     //Chanel Configuration - Mono
                         0x00,          //Index in String Descriptor of the Chanel name       
                         0x00,          //Index in String Descriptor of the Terminal name    

//Output Terminal Descriptor for SB Line OUT

                         0x09,          //Output Terminal Descriptor Length   
                         CS_Interface,  //CS Interface Descriptor Type
                         Out_Terminal,  //Subtype - Output Terminal    
                         0x02,          //Terminal ID
                         0x01,0x03,     //Terminal Type - USB Speaker
                         0x00,          //Terminal Association - none         
                         0x01,          //ID of source terminal
                         0x00,          //Index in String Descriptor of the Terminal name                               


//Input Terminal Descriptor for SB Line IN

                         0x0C,          //Input Terminal Descriptor Length  
                         CS_Interface,  //CS Interface Descriptor Type
                         In_Terminal,   //Subtype - Input Terminal    
                         0x03,          //Terminal ID
                         0x01,0x02,     //Terminal Type - Microphone
                         0x00,          //Terminal Association - none      
                         0x01,          //Number of output chanels
                         0x00,0x00,     //Chanel Configuration - Mono
                         0x00,          //Index in String Descriptor of the Chanel name       
                         0x00,          //Index in String Descriptor of the Terminal name    


//Output Terminal Descriptor for SB Line IN

                         0x09,          //Output Terminal Descriptor Length   
                         CS_Interface,  //CS Interface Descriptor Type
                         Out_Terminal,  //Subtype - Output Terminal    
                         0x04,          //Terminal ID
                         0x01,0x01,     //Terminal Type - USB Streaming
                         0x00,          //Terminal Association - none         
                         0x03,          //ID of source terminal
                         0x00,          //Index in String Descriptor of the Terminal name                               






//Audio Streaming interface Descriptor. Alternate setting 0 (Zero bandwith) for SB Line Out
 
                         0x09,          //AS Interface length
                         0x04,          //Interface Descriptor Type
                         0x01,          //Index of this Interface    
                         0x00,          //Index of this Alternate settings
                         0x00,          //No Endpoints (Uses EP0) 
                         Audio,         //Interface Class - Audio
                         AudioStreaming,//Interface SubClass - Streaming
                         0x00,          //Protocol
                         0x00,          //No string of Interface name  

//Audio Streaming interface Descriptor. Alternate setting 1 (Normal operational mode) for SB Line Out

                         0x09,          //AS Interface length
                         0x04,          //Interface Descriptor Type
                         0x01,          //Index of this Interface    
                         0x01,          //Index of this Alternate settings
                         0x01,          //One Isochronous Out endpoint
                         Audio,         //Interface Class - Audio
                         AudioStreaming,//Interface SubClass - Streaming
                         0x00,          //Protocol
                         0x00,          //No string of Interface name                      

//Class Specific AS Interface Descriptor for SB Line Out
             
                         0x07,          //AS CS interface length
                         CS_Interface,  //CS_INTERFACE Descriptor Type
                         AS_General,    //Subtype - AS_GENERAL
                         0x01,          //Terminal ID conected to         
                         0x01,          //Interface delay (Frame)
                         0x02,0x00,     //Audio Data Format - PCM8        

//Type 1 Format Type Descriptor for SB Line Out

                         0x0B,          //Format Type Descriptor Length 
                         CS_Interface,  //CS_INTERFACE Descriptor Type
                         Format_Type,   //Subtype -Format                              
                         0x01,          //Format Type 1
                         0x01,          //Number of phisical chanels 
                         0x01,          //Number of bytes in subframe
                         0x08,          //Number of bits per sample
                         0x01,          //Number of frequencies supported   
                         0x40,          //Sample frequency is 8000 Hz
                         0x1F,
                         0x00,      
                         
//Standart AS Isochronous Audio Data Endpoint Descriptor for SB Line Out

                         0x09,          //Length of this Descriptor
                         ENDPOINT,      //Descriptor Type
                         0x02,          //Out Endpoint 2 
                         0x0D,          //Transfer Type=SYNCHR. ISO 
                         0x08,0x00,     //Maximum packet size (8)
                         0x01,          //Poling interval
                         0x00,          //Refresh (Not Used)  
                         0x00,          //Sync Endpoint (Not Used) 

//Class-Specific AS Isochronous Audio Data Endpoint Descriptor for SB Line Out

                         0x07,          //Length of this descriptor
                         CS_Endpoint,   //Descriptor Type
                         0x01,          //Subtype=EP_General
                         0x00,          //No Attributes
                         0x00,          //Lock delay (unit) - undefined     
                         0x00,0x00,     //Lock delay (time) - undefined     



//Audio Streaming interface Descriptor. Alternate setting 0 (Zero bandwith) for SB Line IN
 
                         0x09,          //AS Interface length
                         0x04,          //Interface Descriptor Type
                         0x02,          //Index of this Interface    
                         0x00,          //Index of this Alternate settings
                         0x00,          //No Endpoints (Uses EP0) 
                         Audio,         //Interface Class - Audio
                         AudioStreaming,//Interface SubClass - Streaming
                         0x00,          //Protocol
                         0x00,          //No string of Interface name  

//Audio Streaming interface Descriptor. Alternate setting 1 (Normal operational mode) for SB Line IN

                         0x09,          //AS Interface length
                         0x04,          //Interface Descriptor Type
                         0x02,          //Index of this Interface    
                         0x01,          //Index of this Alternate settings
                         0x01,          //One Isochronous In endpoint
                         Audio,         //Interface Class - Audio
                         AudioStreaming,//Interface SubClass - Streaming
                         0x00,          //Protocol
                         0x00,          //No string of Interface name                           

//Class Specific AS Interface Descriptor for SB Line In
             
                         0x07,          //AS CS interface length
                         CS_Interface,  //CS_INTERFACE Descriptor Type
                         AS_General,    //Subtype - AS_GENERAL
                         0x04,          //Terminal ID conected to         
                         0x01,          //Interface delay (Frame)
                         0x02,0x00,     //Audio Data Format - PCM8        

//Type 1 Format Type Descriptor for SB Line In

                         0x0B,          //Format Type Descriptor Length 
                         CS_Interface,  //CS_INTERFACE Descriptor Type
                         Format_Type,   //Subtype -Format                              
                         0x01,          //Format Type 1
                         0x01,          //Number of phisical chanels 
                         0x01,          //Number of bytes in subframe
                         0x08,          //Number of bits per sample
                         0x01,          //Number of frequencies supported   
                         0x40,          //Sample frequency is 8000 Hz
                         0x1F,
                         0x00,      

//Standart AS Isochronous Audio Data Endpoint Descriptor for SB Line In

                         0x09,          //Length of this Descriptor
                         ENDPOINT,      //Descriptor Type
                         0x81,          //In Endpoint 1 
                         0x0D,          //Transfer Type=SYNCHR. ISO 
                         0x08,0x00,     //Maximum packet size (8)
                         0x01,          //Poling interval
                         0x00,          //Refresh (Not Used)  
                         0x00,          //Sync Endpoint (Not Used) 

//Class-Specific AS Isochronous Audio Data Endpoint Descriptor for SB Line In

                         0x07,          //Length of this descriptor
                         CS_Endpoint,   //Descriptor Type
                         0x01,          //Subtype=EP_General
                         0x00,          //No Attributes
                         0x00,          //Lock delay (unit) - undefined     
                         0x00,0x00      //Lock delay (time) - undefined     
                         };      

#define DEV_DESC_SIZE sizeof(DEV_DESC)
#define CFG_DESC_SIZE sizeof(CFG_DESC)


flash char STR_DATA[] = {4,3,9,4             //LANGID array (English) 4-Length of String Descriptor
                                             // 3-Descriptor Type=String , LangID=0x0409-American 
//Addr - [4] MFG_STR= "KS Labs Ltd"
     , 24,3, 'K',0, 'S',0, ' ',0, 'L',0, 'a',0, 'b',0, 's',0, ' ',0, 'L',0, 't',0, 'd',0                    

//Addr - [28] PID_STR= "USB Audio"
     , 20,3, 'U',0, 'S',0, 'B',0, ' ',0, 'A',0, 'u',0, 'd',0, 'i',0, 'o',0

//Addr - [38] NBR_STR= "00003" 
     , 12,3, '0' ,0, '0' ,0, '0' ,0, '0' ,0, '3' ,0};


#define MFG_STR      1
#define PID_STR      2
#define SNBR_STR     3

#define MFG_STR_L    24
#define PID_STR_L    20
#define SNBR_STR_L   12

