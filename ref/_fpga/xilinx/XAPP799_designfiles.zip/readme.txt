XAPP799_Readme.txt

This project has been implemented using the ISE7.1.02i software.

There are two verilog source files and one test bench.
	+ The top level source file is named top.v
	+ The lower level source file is named i2c_module_mod.v
	+ The test bench is top_tb.tbw.  It was created using Xilinx' HDL Bencher program

Upon opening, the project should be fully implemented.  
It is recommended to do a Post Fit Simulation (Timing Simulation) as you will see 
the design respond to a slave address, a write command and a read command.  


** IMPORTANT **

In order to for timing simulation to properly simulate an external Pull Up 
on the pld_i2c_sda pin, the top_timesim.v file MUST be edited.

You must also append the top_timesim.v file 
with the following:  

   X_PU X_PU1     	
        (
       	.O (pld_i2c_sda)
	);

Note that the timesim.v file will change if the source code changes.  Thus, 
you will have to edit the top_timesim.v file accordingly when changes occur.