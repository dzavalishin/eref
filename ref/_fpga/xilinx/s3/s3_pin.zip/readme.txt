SPARTAN-3 FPGA PINOUT INFORMATION
============================================================
Release Date:  13-JULY-2005, v1.4.2


This archive contains two directories.

*  The /tables directory contains comma-delimited ASCII text
   files for each package type.  These files can be viewed
   and sorted using a spreadsheet program, viewed using a
   text editor, or parsed with user-created scripts.  Each
   line in the file represents one pin on the package.

*  The /footprints directory contains Excel spreadsheets that
   show a footprint or map for each package type.

Note that the Pb-free and standard packages have identical
pinouts.  For example, the information in the vq100_table.csv
file in the /tables directory applies to both the VQ100 and
the Pb-free VQG100, and the information in the vq100_footprint.xls
file in the /footprints directory applies to both the VQ100
and the Pb-free VQG100.


PINOUT TABLES
=============

The comma-delimited ASCII text files located in the /tables
directory list pinout information for a specific package
type.  Each line represents one pin on the package.

Pinout information for all Spartan-3 devices available in the
package appears on the line.

Here is a brief description of the fields available on each
line.

    SORT_PIN (QFP packages only)
    --------
    Sorting by SORT_PIN orders the pins sequentially on the 
    quad flat pack style packages such as the VQ100, the TQ144,
    and the PQ208.

    SORT_ROW (BGA packages only)
    --------
    Sorting by SORT_ROW orders the pins alphabetically on 
    the ball grid array packages such as the FT256, FG456,
    FG676, FG900, and FG1156.  Sorting by SORT_ROW is 
    sufficient for the smaller BGA packages.  However, the
    larger BGA packages have ROW indices such as "AA", "AB",
    etc.  An additional field, called SORT_ROW_#, is 
    provided on the large BGA packages to aid sorting.

    SORT_ROW_# (large BGA packages only)
    ----------
    The SORT_ROW_# is similar to SORT_ROW, except that
    SORT_ROW_# is an integer value instead of an alphabetic
    value.  Used for sorting pins on the larger BGA packages
    such as the FG676, FG900, and FG1156.

    SORT_COLUMN (BGA packages only)
    -----------
    SORT_COLUMN is an integer value indicating the column
    number of the pin on a BGA package.

    PIN_NUMBER
    ----------
    The pin identifier for each pin on the package.

For a particular package, there may be multiple Spartan-3
FPGAs available in that package.  For each pin, all the
possible Spartan-3 FPGAs are listed.  Each device is
represented by two fields on each line, XC3S** and
XC3S**_TYPE.  See the following descriptions.

    XC3S**
    ------
    The XC3S** field indicates the name for a particular 
    package pin and for a particular Spartan-3 device in
    that package.  The "**" characters here indicate a 
    wildcard character.  In the pinout table file, the "**"
    characters are replaced by an actual part number, such
    as XC3S400.

    XC3S**_TYPE
    -----------
    The XC3S**_TYPE field indicates the pin type for a
    particular package pin and for a particular Spartan-3
    device in that package.  The listed type matches those
    described in Module 4 of the Spartan-3 data sheet. The 
    "**" characters here indicate a wildcard character.
    In the pinout table file, the "**" characters are 
    replaced by an actual part number, such as XC3S400.

    BANK
    ----
    Sorting by BANK orders the pins by their associated I/O 
    bank.  The possible values for BANK include integers
    between 0 and 7, "VCCAUX", and "N/A".  "N/A" indicates
    that the pin is not associated with a specific bank.

HINTS
-----
To locate unconnected pins in a package type, sort by the TYPE
of the smallest device offered in the package footprint.  Any
unconnected pins on larger devices are a subset of those on
the smallest device.


FOOTPRINT DIAGRAMS
==================

The files in the \footprints directory are all Microsoft Excel
spreadsheet files.  These files present a common footprint for
each package type and show the pins on the package as viewed
from the top (QFP packages) or through the top of the package
(BGA packages).  Note the location of the pin 1 indicator on
QFP packages.

Each pin is labeled and color coded according to Module 4 of
the Spartan-3 data sheet.  No Connect (N.C.) pins are also
indicated with special symbols.

Most footprints were saved as 50% of normal size so that the
entire footprint is visible on the screen.  To change the 
magnification, select View --> Zoom from the Excel top menu, 
then select the desired magnification factor.

Excel may issue a warning when you open the file indicating
that the file may contain macros.  Select either "Disable
Macros" or "Enable Macros".  There are no longer any active
macros in the Excel files.


REVISION HISTORY:
================

v1.0: Initial release.

v1.1: Added VQ100 package pinout information.

v1.2: Corrected LVDS pin naming errors on FG1156 package
      pinout.

v1.3: Added FG320 package pinout information.

v1.4: Added XC3S50CP132, XC3S2000FG456, and
      XC3S4000FG676 device/package combinations

v1.4.1: Added Pb-free note to this readme file

v1.4.2: Added XC3S1000 to title in FG456_footprint.xls 

[Xilinx GPD Applications Engineering, 13-JULY-2005]